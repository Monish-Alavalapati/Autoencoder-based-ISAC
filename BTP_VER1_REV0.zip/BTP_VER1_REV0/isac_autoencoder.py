"""
╔════════════════════════════════════════════════════════════════════════════╗
║                    ISAC Adaptive Autoencoder                               ║
║                                                                            ║
║  An intelligent neural network receiver for Integrated Sensing and        ║
║  Communication (ISAC) systems that adaptively learns optimal radar        ║
║  power allocation (omega_r) from data characteristics.                    ║
╚════════════════════════════════════════════════════════════════════════════╝

WORKFLOW:
  1. Generate dataset:  Run generate_isac_dataset.m in MATLAB
  2. Train & evaluate:  python isac_autoencoder.py

ARCHITECTURE:
  The model consists of:
  - OmegaPredictor:      Learns optimal omega_r from signal characteristics
  - PresenceDetector:    Detects target presence from radar return
  - AngleEstimator:      Estimates target angle of arrival
  - UncertaintyEstimator: Estimates uncertainty in angle estimation
  - CommReceiver:        Recovers transmitted message with CSI
"""

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import matplotlib.pyplot as plt
import h5py
import scipy.io
from pathlib import Path
from dataclasses import dataclass
from typing import Tuple, Optional


# ╔════════════════════════════════════════════════════════════════════════════╗
# ║                         CONFIGURATION                                      ║
# ╚════════════════════════════════════════════════════════════════════════════╝

@dataclass
class Config:
    """Training and model configuration"""
    # Device
    device: str = 'cuda' if torch.cuda.is_available() else 'cpu'
    
    # Training hyperparameters
    batch_size: int = 512
    num_epochs: int = 50
    learning_rate: float = 0.001
    weight_decay: float = 1e-5
    
    # Learning rate schedule
    lr_step_size: int = 15
    lr_gamma: float = 0.5
    
    # Loss weights (default, can be adapted)
    default_omega_r: float = 0.09
    
    # Gradient clipping
    max_grad_norm: float = 5.0
    
    # Baseline targets from paper (for comparison)
    baseline_omega_r: list = None
    baseline_ser: list = None
    baseline_pd: list = None
    
    def __post_init__(self):
        # Paper baseline values (approximate from Fig. 1)
        self.baseline_omega_r = [0.01, 0.03, 0.09, 0.15, 0.4, 0.6, 0.7, 0.9]
        self.baseline_ser = [0.55, 0.40, 0.02, 0.018, 0.02, 0.025, 0.03, 0.04]
        self.baseline_pd = [0.20, 0.25, 0.35, 0.50, 0.80, 0.92, 0.95, 0.98]


config = Config()
print(f"Device: {config.device}")


# ╔════════════════════════════════════════════════════════════════════════════╗
# ║                         MODEL ARCHITECTURES                                ║
# ║                         (Based on Table I)                                 ║
# ╚════════════════════════════════════════════════════════════════════════════╝

class OmegaPredictor(nn.Module):
    """
    Learns to predict optimal omega_r from signal characteristics.
    
    This network analyzes both radar and communication signals to determine
    the optimal trade-off factor between radar and communication performance.
    """
    def __init__(self, K: int):
        super().__init__()
        input_dim = 2*K + 4  # Radar features (2K) + Comm features (4)
        
        self.net = nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.LayerNorm(64),
            nn.ReLU(),
            nn.Dropout(0.1),
            
            nn.Linear(64, 32),
            nn.LayerNorm(32),
            nn.ReLU(),
            
            nn.Linear(32, 16),
            nn.ReLU(),
            
            nn.Linear(16, 1),
            nn.Sigmoid()  # Output in [0, 1]
        )
    
    def forward(self, zr_feat: torch.Tensor, zc_feat: torch.Tensor) -> torch.Tensor:
        combined = torch.cat([zr_feat, zc_feat], dim=1)
        return self.net(combined)


class PresenceDetector(nn.Module):
    """
    Detects target presence from radar return signal.
    
    Architecture: 2K -> 2K -> 2K -> K -> 1 (sigmoid)
    """
    def __init__(self, K: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(2*K, 2*K),
            nn.ReLU(),
            nn.Linear(2*K, 2*K),
            nn.ReLU(),
            nn.Linear(2*K, K),
            nn.ReLU(),
            nn.Linear(K, 1),
            nn.Sigmoid()
        )
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class AngleEstimator(nn.Module):
    """
    Estimates target angle of arrival (AoA).
    
    Architecture: 2K -> 2K -> 2K -> K -> 1 (tanh scaled to [-π/2, π/2])
    """
    def __init__(self, K: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(2*K, 2*K),
            nn.ReLU(),
            nn.Linear(2*K, 2*K),
            nn.ReLU(),
            nn.Linear(2*K, K),
            nn.ReLU(),
            nn.Linear(K, 1),
            nn.Tanh()
        )
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x) * (np.pi / 2)


class UncertaintyEstimator(nn.Module):
    """
    Estimates uncertainty (standard deviation) in angle estimation.
    
    Architecture: 2K -> 2K -> 2K -> K -> 1 (softplus + offset for positivity)
    """
    def __init__(self, K: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(2*K, 2*K),
            nn.ReLU(),
            nn.Linear(2*K, 2*K),
            nn.ReLU(),
            nn.Linear(2*K, K),
            nn.ReLU(),
            nn.Linear(K, 1),
            nn.Softplus()
        )
        self.min_sigma = 0.01  # Minimum uncertainty
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x) + self.min_sigma


class CommReceiver(nn.Module):
    """
    Recovers transmitted message from received communication signal.
    
    Input: [z_c_real, z_c_imag, kappa_real, kappa_imag] (with CSI)
    Architecture: 4 -> K -> 2K -> 2K -> M
    """
    def __init__(self, M: int, K: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(4, K),
            nn.ReLU(),
            nn.Linear(K, 2*K),
            nn.ReLU(),
            nn.Linear(2*K, 2*K),
            nn.ReLU(),
            nn.Linear(2*K, M)
        )
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class AdaptiveISACReceiver(nn.Module):
    """
    Complete Adaptive ISAC Receiver.
    
    This model combines all sub-networks and includes an omega predictor
    that learns to adaptively weight radar vs communication losses based
    on signal characteristics.
    """
    def __init__(self, K: int, M: int):
        super().__init__()
        self.K = K
        self.M = M
        
        # Sub-networks
        self.omega_predictor = OmegaPredictor(K)
        self.presence_detector = PresenceDetector(K)
        self.angle_estimator = AngleEstimator(K)
        self.uncertainty_estimator = UncertaintyEstimator(K)
        self.comm_receiver = CommReceiver(M, K)
    
    def forward(self, zr_feat: torch.Tensor, zc_feat: torch.Tensor) -> Tuple[torch.Tensor, ...]:
        """
        Forward pass through all sub-networks.
        
        Args:
            zr_feat: Radar features [batch, 2K] (real and imag parts)
            zc_feat: Comm features [batch, 4] (z_c and kappa, real/imag)
        
        Returns:
            omega_pred: Predicted optimal omega_r [batch, 1]
            q:          Detection probability [batch, 1]
            theta_hat:  Estimated angle [batch, 1]
            sigma_hat:  Estimated uncertainty [batch, 1]
            m_logits:   Message logits [batch, M]
        """
        omega_pred = self.omega_predictor(zr_feat, zc_feat)
        q = self.presence_detector(zr_feat)
        theta_hat = self.angle_estimator(zr_feat)
        sigma_hat = self.uncertainty_estimator(zr_feat)
        m_logits = self.comm_receiver(zc_feat)
        
        return omega_pred, q, theta_hat, sigma_hat, m_logits
    
    def count_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


# ╔════════════════════════════════════════════════════════════════════════════╗
# ║                         LOSS FUNCTIONS                                     ║
# ╚════════════════════════════════════════════════════════════════════════════╝

def compute_adaptive_loss(
    omega_pred: torch.Tensor,
    omega_true: torch.Tensor,
    q: torch.Tensor,
    theta_hat: torch.Tensor,
    sigma_hat: torch.Tensor,
    m_logits: torch.Tensor,
    t: torch.Tensor,
    theta_true: torch.Tensor,
    m_true: torch.Tensor
) -> Tuple[torch.Tensor, dict]:
    """
    Compute the adaptive ISAC loss.
    
    The loss is weighted by the predicted omega_r, allowing the model
    to learn the optimal trade-off between radar and communication.
    
    Args:
        omega_pred: Predicted omega_r [batch, 1]
        omega_true: True omega_r used in data generation [batch, 1]
        q:          Detection probability [batch, 1]
        theta_hat:  Estimated angle [batch, 1]
        sigma_hat:  Estimated uncertainty [batch, 1]
        m_logits:   Message logits [batch, M]
        t:          True target presence [batch, 1]
        theta_true: True target angle [batch, 1]
        m_true:     True message index [batch]
    
    Returns:
        total_loss: Combined loss
        loss_dict:  Dictionary with individual loss components
    """
    eps = 1e-7
    
    # Use true omega_r for weighting (model learns to predict this)
    omega = omega_true.squeeze()
    
    # 1. Omega prediction loss (learn to predict optimal omega_r)
    loss_omega = nn.functional.mse_loss(omega_pred.squeeze(), omega)
    
    # 2. Radar detection loss (Binary Cross Entropy)
    loss_det = -torch.mean(
        t.squeeze() * torch.log(q.squeeze() + eps) + 
        (1 - t.squeeze()) * torch.log(1 - q.squeeze() + eps)
    )
    
    # 3. Radar regression loss (Negative Log Likelihood for angle)
    nll = torch.log(sigma_hat.squeeze() + eps) + \
          0.5 * ((theta_true.squeeze() - theta_hat.squeeze())**2) / (sigma_hat.squeeze()**2 + eps)
    loss_reg = torch.mean(t.squeeze() * nll)
    
    # 4. Communication loss (Cross Entropy)
    loss_comm = nn.functional.cross_entropy(m_logits, m_true)
    
    # 5. Combined loss with adaptive weighting
    # Higher omega_r -> more weight on radar losses
    radar_loss = loss_det + 0.5 * loss_reg
    
    # Use mean omega for weighting in this batch
    omega_mean = omega.mean()
    total_loss = (
        0.1 * loss_omega +                          # Learn omega prediction
        omega_mean * radar_loss +                   # Radar losses
        (1 - omega_mean) * loss_comm                # Communication loss
    )
    
    loss_dict = {
        'total': total_loss.item(),
        'omega': loss_omega.item(),
        'detection': loss_det.item(),
        'regression': loss_reg.item(),
        'comm': loss_comm.item()
    }
    
    return total_loss, loss_dict


# ╔════════════════════════════════════════════════════════════════════════════╗
# ║                         DATA LOADING                                       ║
# ╚════════════════════════════════════════════════════════════════════════════╝

def load_dataset(filepath: str = 'isac_data.mat'):
    """
    Load ISAC dataset generated by MATLAB.
    
    Handles both HDF5 (v7.3) and older MATLAB formats.
    """
    print(f"Loading dataset: {filepath}")
    
    try:
        # Try HDF5 format (MATLAB v7.3)
        with h5py.File(filepath, 'r') as f:
            train = _load_group(f['train'])
            test = _load_group(f['test'])
            params = _load_group(f['params'])
    except (OSError, KeyError):
        # Fallback to scipy for older format
        mat = scipy.io.loadmat(filepath, squeeze_me=True, struct_as_record=False)
        train = mat['train']
        test = mat['test']
        params = mat['params']
    
    return train, test, params


def _load_group(group) -> object:
    """Helper to load HDF5 group as Python object."""
    obj = type('MatStruct', (), {})()
    
    def convert_complex(val):
        if isinstance(val, np.ndarray) and val.dtype.names == ('real', 'imag'):
            return val['real'] + 1j * val['imag']
        return val
    
    for key in group.keys():
        val = group[key][()]
        if isinstance(val, np.ndarray) and val.ndim > 1:
            val = val.T
        val = convert_complex(val)
        if isinstance(val, np.ndarray) and val.size == 1:
            try:
                val = val.item()
            except:
                pass
        setattr(obj, key, val)
    
    return obj


def prepare_tensors(data, device: str) -> dict:
    """Convert loaded data to PyTorch tensors."""
    tensors = {}
    
    # Message indices (0-indexed for PyTorch)
    m_idx = np.array(data.m_idx).squeeze()
    tensors['m_idx'] = torch.tensor(m_idx - 1, dtype=torch.long, device=device)
    
    # Target presence
    t = np.array(data.target_present).squeeze()
    tensors['t'] = torch.tensor(t, dtype=torch.float32, device=device).unsqueeze(1)
    
    # True angles
    theta = np.array(data.theta_true).squeeze()
    tensors['theta'] = torch.tensor(theta, dtype=torch.float32, device=device).unsqueeze(1)
    
    # Omega_r values
    omega = np.array(data.omega_r).squeeze()
    tensors['omega_r'] = torch.tensor(omega, dtype=torch.float32, device=device).unsqueeze(1)
    
    # Radar features [batch, 2K]
    Y_radar = np.array(data.Y_radar, dtype=np.complex128)
    Y_radar_t = torch.tensor(Y_radar, dtype=torch.complex64, device=device)
    tensors['zr_feat'] = torch.cat([Y_radar_t.real, Y_radar_t.imag], dim=1)
    
    # Communication features [batch, 4]
    Y_comm = np.array(data.Y_comm, dtype=np.complex128).squeeze()
    kappa = np.array(data.kappa, dtype=np.complex128).squeeze()
    
    Y_comm_t = torch.tensor(Y_comm, dtype=torch.complex64, device=device)
    kappa_t = torch.tensor(kappa, dtype=torch.complex64, device=device)
    
    if Y_comm_t.dim() == 1:
        Y_comm_t = Y_comm_t.unsqueeze(1)
    if kappa_t.dim() == 1:
        kappa_t = kappa_t.unsqueeze(1)
    
    tensors['zc_feat'] = torch.cat([
        Y_comm_t.real, Y_comm_t.imag,
        kappa_t.real, kappa_t.imag
    ], dim=1)
    
    return tensors


# ╔════════════════════════════════════════════════════════════════════════════╗
# ║                         TRAINING                                           ║
# ╚════════════════════════════════════════════════════════════════════════════╝

def train_model(
    model: AdaptiveISACReceiver,
    train_tensors: dict,
    config: Config
) -> dict:
    """
    Train the adaptive ISAC receiver.
    
    Returns:
        history: Dictionary containing training metrics for each epoch
    """
    optimizer = optim.Adam(
        model.parameters(),
        lr=config.learning_rate,
        weight_decay=config.weight_decay
    )
    scheduler = optim.lr_scheduler.StepLR(
        optimizer,
        step_size=config.lr_step_size,
        gamma=config.lr_gamma
    )
    
    N = train_tensors['m_idx'].shape[0]
    history = {'loss': [], 'loss_omega': [], 'loss_det': [], 'loss_reg': [], 'loss_comm': []}
    
    print("\n" + "═" * 70)
    print("                         TRAINING")
    print("═" * 70)
    print(f"  Epochs: {config.num_epochs}")
    print(f"  Batch size: {config.batch_size}")
    print(f"  Learning rate: {config.learning_rate}")
    print(f"  Samples: {N:,}")
    print("═" * 70 + "\n")
    
    for epoch in range(config.num_epochs):
        model.train()
        perm = torch.randperm(N)
        
        epoch_losses = {k: 0.0 for k in history.keys()}
        num_batches = 0
        
        for i in range(0, N, config.batch_size):
            idx = perm[i:min(i + config.batch_size, N)]
            
            # Forward pass
            omega_pred, q, theta_hat, sigma_hat, m_logits = model(
                train_tensors['zr_feat'][idx],
                train_tensors['zc_feat'][idx]
            )
            
            # Compute loss
            loss, loss_dict = compute_adaptive_loss(
                omega_pred, train_tensors['omega_r'][idx],
                q, theta_hat, sigma_hat, m_logits,
                train_tensors['t'][idx],
                train_tensors['theta'][idx],
                train_tensors['m_idx'][idx]
            )
            
            # Backward pass
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), config.max_grad_norm)
            optimizer.step()
            
            # Accumulate losses
            epoch_losses['loss'] += loss_dict['total']
            epoch_losses['loss_omega'] += loss_dict['omega']
            epoch_losses['loss_det'] += loss_dict['detection']
            epoch_losses['loss_reg'] += loss_dict['regression']
            epoch_losses['loss_comm'] += loss_dict['comm']
            num_batches += 1
        
        scheduler.step()
        
        # Average losses
        for k in epoch_losses:
            epoch_losses[k] /= num_batches
            history[k].append(epoch_losses[k])
        
        # Log progress
        if (epoch + 1) % 5 == 0 or epoch == 0:
            lr = scheduler.get_last_lr()[0]
            print(f"  Epoch {epoch+1:3d}/{config.num_epochs} │ "
                  f"Loss: {epoch_losses['loss']:.4f} │ "
                  f"Comm: {epoch_losses['loss_comm']:.4f} │ "
                  f"Det: {epoch_losses['loss_det']:.4f} │ "
                  f"LR: {lr:.6f}")
    
    print("\n" + "═" * 70)
    print("                    TRAINING COMPLETE")
    print("═" * 70 + "\n")
    
    return history


# ╔════════════════════════════════════════════════════════════════════════════╗
# ║                         EVALUATION                                         ║
# ╚════════════════════════════════════════════════════════════════════════════╝

@torch.no_grad()
def evaluate(
    model: AdaptiveISACReceiver,
    test_tensors: dict,
    omega_r_values: Optional[list] = None,
    P_fa_target: float = 0.01
) -> dict:
    """
    Evaluate model performance across different omega_r values.
    
    Args:
        model: Trained model
        test_tensors: Test data tensors
        omega_r_values: List of omega_r values to evaluate (if None, evaluate overall)
        P_fa_target: Target false alarm probability for threshold setting
    
    Returns:
        results: Dictionary with metrics for each omega_r or overall
    """
    model.eval()
    
    if omega_r_values is None:
        # Overall evaluation
        return _evaluate_subset(model, test_tensors, None, P_fa_target)
    
    # Evaluate for each omega_r value
    results = {}
    for omega in omega_r_values:
        # Find samples with this omega_r (with tolerance)
        mask = torch.abs(test_tensors['omega_r'].squeeze() - omega) < 0.01
        
        if mask.sum() > 100:  # Need enough samples
            subset = {k: v[mask] for k, v in test_tensors.items()}
            results[omega] = _evaluate_subset(model, subset, omega, P_fa_target)
        else:
            print(f"  Warning: Not enough samples for omega_r={omega:.2f}")
    
    return results


def _evaluate_subset(
    model: AdaptiveISACReceiver,
    tensors: dict,
    omega_r: Optional[float],
    P_fa_target: float
) -> dict:
    """Evaluate on a subset of data."""
    omega_pred, q, theta_hat, sigma_hat, m_logits = model(
        tensors['zr_feat'],
        tensors['zc_feat']
    )
    
    t = tensors['t'].squeeze()
    q = q.squeeze()
    
    # Set detection threshold based on P_fa target
    q_h0 = q[t == 0]
    if len(q_h0) > 0:
        threshold = torch.quantile(q_h0, 1 - P_fa_target)
    else:
        threshold = 0.5
    
    t_hat = (q > threshold).float()
    
    # Detection metrics
    Pd = (t_hat[t == 1] == 1).float().mean().item() if (t == 1).sum() > 0 else 0
    Pfa = (t_hat[t == 0] == 1).float().mean().item() if (t == 0).sum() > 0 else 0
    
    # RMSE for detected targets
    detected = (t == 1) & (t_hat == 1)
    if detected.sum() > 0:
        RMSE = torch.sqrt(torch.mean(
            (theta_hat.squeeze()[detected] - tensors['theta'].squeeze()[detected])**2
        )).item()
        sigma_mean = sigma_hat.squeeze()[detected].mean().item()
    else:
        RMSE = float('nan')
        sigma_mean = float('nan')
    
    # Symbol Error Rate
    m_pred = torch.argmax(m_logits, dim=1)
    SER = (m_pred != tensors['m_idx']).float().mean().item()
    
    return {
        'SER': SER,
        'Pd': Pd,
        'Pfa': Pfa,
        'RMSE': RMSE,
        'RMSE_deg': np.degrees(RMSE) if not np.isnan(RMSE) else float('nan'),
        'sigma_mean': sigma_mean,
        'threshold': threshold.item() if isinstance(threshold, torch.Tensor) else threshold
    }


# ╔════════════════════════════════════════════════════════════════════════════╗
# ║                         VISUALIZATION                                      ║
# ╚════════════════════════════════════════════════════════════════════════════╝

def plot_results(history: dict, results: dict, config: Config, save_path: str = 'results'):
    """Generate comprehensive result visualizations."""
    
    Path(save_path).mkdir(exist_ok=True)
    
    # Style settings
    plt.style.use('default')
    plt.rcParams.update({
        'figure.facecolor': '#1a1a2e',
        'axes.facecolor': '#16213e',
        'axes.edgecolor': '#e94560',
        'axes.labelcolor': 'white',
        'text.color': 'white',
        'xtick.color': 'white',
        'ytick.color': 'white',
        'grid.color': '#0f3460',
        'font.size': 10
    })
    
    fig, axes = plt.subplots(2, 3, figsize=(15, 10))
    fig.suptitle('ISAC Adaptive Autoencoder Results', fontsize=14, fontweight='bold', color='white')
    
    # 1. Training Loss
    ax = axes[0, 0]
    ax.plot(history['loss'], 'c-', linewidth=2, label='Total')
    ax.plot(history['loss_comm'], 'm-', linewidth=1.5, alpha=0.8, label='Comm')
    ax.plot(history['loss_det'], 'y-', linewidth=1.5, alpha=0.8, label='Detection')
    ax.set_xlabel('Epoch')
    ax.set_ylabel('Loss')
    ax.set_title('Training Loss Curves')
    ax.legend(loc='upper right', facecolor='#16213e', edgecolor='white')
    ax.grid(True, alpha=0.3)
    
    # 2. SER vs Detection Probability (Pareto Curve)
    ax = axes[0, 1]
    omega_values = sorted(results.keys())
    ser_values = [results[w]['SER'] for w in omega_values]
    pd_values = [results[w]['Pd'] for w in omega_values]
    
    # Plot our results
    scatter = ax.scatter(pd_values, ser_values, c=omega_values, cmap='hot', 
                         s=100, edgecolors='white', linewidths=2, zorder=3)
    ax.plot(pd_values, ser_values, 'w--', alpha=0.5, linewidth=1)
    
    # Add baseline
    ax.scatter(config.baseline_pd, config.baseline_ser, 
               marker='^', c='cyan', s=80, label='Baseline', alpha=0.7, zorder=2)
    ax.plot(config.baseline_pd, config.baseline_ser, 'c--', alpha=0.3)
    
    ax.set_xlabel('Detection Probability (Pd)')
    ax.set_ylabel('Symbol Error Rate (SER)')
    ax.set_title('SER vs Pd (Pareto Curve)')
    ax.set_yscale('log')
    ax.legend(loc='upper right', facecolor='#16213e', edgecolor='white')
    ax.grid(True, alpha=0.3)
    
    # Colorbar
    cbar = plt.colorbar(scatter, ax=ax)
    cbar.set_label('ω_r', color='white')
    cbar.ax.yaxis.set_tick_params(color='white')
    plt.setp(plt.getp(cbar.ax.axes, 'yticklabels'), color='white')
    
    # 3. Performance vs omega_r
    ax = axes[0, 2]
    ax.plot(omega_values, ser_values, 'o-', color='#e94560', linewidth=2, 
            markersize=8, label='SER (ours)')
    ax.plot(config.baseline_omega_r, config.baseline_ser, '^--', color='cyan', 
            alpha=0.7, label='SER (baseline)')
    ax.set_xlabel('ω_r (Radar Allocation)')
    ax.set_ylabel('SER')
    ax.set_title('SER vs ω_r')
    ax.set_yscale('log')
    ax.legend(loc='best', facecolor='#16213e', edgecolor='white')
    ax.grid(True, alpha=0.3)
    
    # 4. Pd vs omega_r
    ax = axes[1, 0]
    ax.plot(omega_values, pd_values, 's-', color='#00ff88', linewidth=2, 
            markersize=8, label='Pd (ours)')
    ax.plot(config.baseline_omega_r, config.baseline_pd, '^--', color='cyan', 
            alpha=0.7, label='Pd (baseline)')
    ax.set_xlabel('ω_r (Radar Allocation)')
    ax.set_ylabel('Detection Probability')
    ax.set_title('Pd vs ω_r')
    ax.legend(loc='best', facecolor='#16213e', edgecolor='white')
    ax.grid(True, alpha=0.3)
    
    # 5. RMSE vs omega_r
    ax = axes[1, 1]
    rmse_values = [results[w]['RMSE_deg'] for w in omega_values]
    ax.plot(omega_values, rmse_values, 'd-', color='#ffa500', linewidth=2, markersize=8)
    ax.set_xlabel('ω_r (Radar Allocation)')
    ax.set_ylabel('RMSE (degrees)')
    ax.set_title('Angle RMSE vs ω_r')
    ax.grid(True, alpha=0.3)
    
    # 6. Performance Summary Table
    ax = axes[1, 2]
    ax.axis('off')
    
    # Create table data
    table_data = []
    headers = ['ω_r', 'SER', 'Pd', 'RMSE°']
    for omega in omega_values[:6]:  # Show first 6
        r = results[omega]
        table_data.append([
            f'{omega:.2f}',
            f'{r["SER"]:.4f}',
            f'{r["Pd"]:.3f}',
            f'{r["RMSE_deg"]:.2f}'
        ])
    
    table = ax.table(
        cellText=table_data,
        colLabels=headers,
        loc='center',
        cellLoc='center',
        colColours=['#0f3460'] * 4
    )
    table.auto_set_font_size(False)
    table.set_fontsize(10)
    table.scale(1.2, 1.5)
    
    # Style table
    for (row, col), cell in table.get_celld().items():
        cell.set_edgecolor('white')
        cell.set_text_props(color='white')
        if row == 0:
            cell.set_facecolor('#e94560')
        else:
            cell.set_facecolor('#16213e')
    
    ax.set_title('Performance Summary', pad=20)
    
    plt.tight_layout()
    plt.savefig(f'{save_path}/isac_results.png', dpi=150, 
                facecolor='#1a1a2e', edgecolor='none', bbox_inches='tight')
    print(f"  ✓ Results saved to {save_path}/isac_results.png")
    
    plt.close()


def plot_hardware_impairments(params, results: dict, save_path: str = 'results'):
    """
    Generate comprehensive hardware impairment analysis visualizations.
    
    This function creates a 2x3 figure showing:
    1. Antenna spacing distribution (perturbations)
    2. Beamforming gain vs omega_r
    3. Performance degradation analysis
    4. Signal quality metrics
    5. Trade-off visualization
    6. Summary statistics
    """
    
    Path(save_path).mkdir(exist_ok=True)
    
    # Extract parameters
    K = int(params.K)
    lambda_val = float(params.lambda_)  if hasattr(params, 'lambda_') else float(getattr(params, 'lambda', 0.125))
    d_nominal = float(params.d_nominal) if hasattr(params, 'd_nominal') else lambda_val / 2
    d_spacings = np.array(params.d_spacings).flatten() if hasattr(params, 'd_spacings') else None
    enable_hw = bool(params.enable_hardware_impairments) if hasattr(params, 'enable_hardware_impairments') else True
    sigma_lambda = float(params.sigma_lambda) if hasattr(params, 'sigma_lambda') else lambda_val / 30
    
    # Style settings for dark theme
    plt.style.use('default')
    plt.rcParams.update({
        'figure.facecolor': '#1a1a2e',
        'axes.facecolor': '#16213e',
        'axes.edgecolor': '#e94560',
        'axes.labelcolor': 'white',
        'text.color': 'white',
        'xtick.color': 'white',
        'ytick.color': 'white',
        'grid.color': '#0f3460',
        'font.size': 10
    })
    
    fig, axes = plt.subplots(2, 3, figsize=(16, 10))
    fig.suptitle('ISAC Hardware Impairment Analysis', fontsize=14, fontweight='bold', color='white')
    
    # Colors
    c_ideal = '#00ff88'
    c_impaired = '#e94560'
    c_accent1 = '#4da6ff'
    c_accent2 = '#ffa500'
    
    # ──────────────────────────────────────────────────────────────────────
    # Plot 1: Antenna Spacing Distribution
    # ──────────────────────────────────────────────────────────────────────
    ax = axes[0, 0]
    
    if d_spacings is not None and len(d_spacings) > 0:
        spacing_error_pct = ((d_spacings - d_nominal) / d_nominal) * 100
        
        bars = ax.bar(range(1, len(spacing_error_pct) + 1), spacing_error_pct, 
                      color=c_accent1, edgecolor='none', alpha=0.8)
        ax.axhline(y=0, color=c_ideal, linestyle='--', linewidth=2, label='Ideal')
        ax.axhline(y=np.mean(spacing_error_pct), color=c_impaired, linestyle='-', 
                   linewidth=1.5, label=f'Mean: {np.mean(spacing_error_pct):.2f}%')
        
        # Statistics annotation
        stats_text = f'σ_λ = λ/30\nStd: {np.std(spacing_error_pct):.2f}%\nMax: {np.max(np.abs(spacing_error_pct)):.2f}%'
        ax.text(0.98, 0.95, stats_text, transform=ax.transAxes, 
                ha='right', va='top', fontsize=9,
                bbox=dict(boxstyle='round', facecolor='#16213e', edgecolor=c_accent1))
    else:
        ax.text(0.5, 0.5, 'No spacing data\navailable', transform=ax.transAxes,
                ha='center', va='center', fontsize=12)
    
    ax.set_xlabel('Antenna Pair Index')
    ax.set_ylabel('Spacing Error (%)')
    ax.set_title('Antenna Spacing Perturbations')
    ax.legend(loc='lower right', facecolor='#16213e', edgecolor='white')
    ax.grid(True, alpha=0.3)
    
    # ──────────────────────────────────────────────────────────────────────
    # Plot 2: Performance vs omega_r (SER and Pd together)
    # ──────────────────────────────────────────────────────────────────────
    ax = axes[0, 1]
    
    omega_values = sorted(results.keys())
    ser_values = [results[w]['SER'] for w in omega_values]
    pd_values = [results[w]['Pd'] for w in omega_values]
    
    ax2 = ax.twinx()
    
    line1, = ax.plot(omega_values, ser_values, 'o-', color=c_impaired, 
                     linewidth=2, markersize=8, label='SER')
    line2, = ax2.plot(omega_values, pd_values, 's-', color=c_ideal, 
                      linewidth=2, markersize=8, label='Pd')
    
    ax.set_xlabel('ω_r (Radar Allocation)')
    ax.set_ylabel('Symbol Error Rate (SER)', color=c_impaired)
    ax2.set_ylabel('Detection Probability (Pd)', color=c_ideal)
    ax.tick_params(axis='y', labelcolor=c_impaired)
    ax2.tick_params(axis='y', labelcolor=c_ideal)
    ax.set_yscale('log')
    ax.set_title('Performance Trade-off vs ω_r')
    ax.grid(True, alpha=0.3)
    
    lines = [line1, line2]
    labels = [l.get_label() for l in lines]
    ax.legend(lines, labels, loc='center right', facecolor='#16213e', edgecolor='white')
    
    # ──────────────────────────────────────────────────────────────────────
    # Plot 3: RMSE vs Uncertainty (Calibration)
    # ──────────────────────────────────────────────────────────────────────
    ax = axes[0, 2]
    
    rmse_values = [results[w]['RMSE_deg'] for w in omega_values]
    sigma_values = [np.degrees(results[w]['sigma_mean']) if not np.isnan(results[w]['sigma_mean']) else np.nan 
                    for w in omega_values]
    
    # Filter out NaN values
    valid_mask = [not (np.isnan(r) or np.isnan(s)) for r, s in zip(rmse_values, sigma_values)]
    valid_rmse = [r for r, v in zip(rmse_values, valid_mask) if v]
    valid_sigma = [s for s, v in zip(sigma_values, valid_mask) if v]
    valid_omega = [o for o, v in zip(omega_values, valid_mask) if v]
    
    if len(valid_rmse) > 0:
        scatter = ax.scatter(valid_sigma, valid_rmse, c=valid_omega, cmap='hot',
                            s=100, edgecolors='white', linewidths=2)
        
        # Perfect calibration line
        max_val = max(max(valid_rmse), max(valid_sigma))
        ax.plot([0, max_val], [0, max_val], 'w--', linewidth=2, alpha=0.5, label='Perfect Calibration')
        
        cbar = plt.colorbar(scatter, ax=ax)
        cbar.set_label('ω_r', color='white')
        cbar.ax.yaxis.set_tick_params(color='white')
        plt.setp(plt.getp(cbar.ax.axes, 'yticklabels'), color='white')
    
    ax.set_xlabel('Estimated Uncertainty (degrees)')
    ax.set_ylabel('Actual RMSE (degrees)')
    ax.set_title('Uncertainty Calibration')
    ax.legend(loc='upper left', facecolor='#16213e', edgecolor='white')
    ax.grid(True, alpha=0.3)
    
    # ──────────────────────────────────────────────────────────────────────
    # Plot 4: Hardware Impairment Impact Summary
    # ──────────────────────────────────────────────────────────────────────
    ax = axes[1, 0]
    
    # Bar chart comparing metrics
    categories = ['Low ω_r\n(0.01-0.09)', 'Med ω_r\n(0.15-0.4)', 'High ω_r\n(0.6-0.9)']
    
    # Compute average metrics for each category
    low_omega = [w for w in omega_values if w <= 0.09]
    med_omega = [w for w in omega_values if 0.09 < w <= 0.4]
    high_omega = [w for w in omega_values if w > 0.4]
    
    def avg_metric(omega_list, metric):
        if not omega_list:
            return 0
        return np.mean([results[w][metric] for w in omega_list if w in results])
    
    ser_by_cat = [avg_metric(low_omega, 'SER'), 
                  avg_metric(med_omega, 'SER'), 
                  avg_metric(high_omega, 'SER')]
    pd_by_cat = [avg_metric(low_omega, 'Pd'), 
                 avg_metric(med_omega, 'Pd'), 
                 avg_metric(high_omega, 'Pd')]
    
    x = np.arange(len(categories))
    width = 0.35
    
    bars1 = ax.bar(x - width/2, ser_by_cat, width, label='SER', color=c_impaired, alpha=0.8)
    bars2 = ax.bar(x + width/2, pd_by_cat, width, label='Pd', color=c_ideal, alpha=0.8)
    
    ax.set_ylabel('Metric Value')
    ax.set_xlabel('ω_r Range')
    ax.set_title('Performance by ω_r Region')
    ax.set_xticks(x)
    ax.set_xticklabels(categories)
    ax.legend(loc='upper center', facecolor='#16213e', edgecolor='white')
    ax.grid(True, alpha=0.3, axis='y')
    
    # ──────────────────────────────────────────────────────────────────────
    # Plot 5: Radar vs Communication Trade-off Curve
    # ──────────────────────────────────────────────────────────────────────
    ax = axes[1, 1]
    
    # Pareto curve
    scatter = ax.scatter(pd_values, ser_values, c=omega_values, cmap='plasma',
                        s=120, edgecolors='white', linewidths=2)
    
    # Connect points
    ax.plot(pd_values, ser_values, 'w-', alpha=0.3, linewidth=1)
    
    # Annotate key points
    for i, omega in enumerate(omega_values):
        if omega in [0.01, 0.09, 0.4, 0.9]:
            ax.annotate(f'ω={omega}', (pd_values[i], ser_values[i]),
                       textcoords='offset points', xytext=(5, 5),
                       fontsize=8, color='white', alpha=0.8)
    
    ax.set_xlabel('Detection Probability (Pd)')
    ax.set_ylabel('Symbol Error Rate (SER)')
    ax.set_title('Radar-Communication Trade-off')
    ax.set_yscale('log')
    ax.grid(True, alpha=0.3)
    
    cbar = plt.colorbar(scatter, ax=ax)
    cbar.set_label('ω_r', color='white')
    cbar.ax.yaxis.set_tick_params(color='white')
    plt.setp(plt.getp(cbar.ax.axes, 'yticklabels'), color='white')
    
    # ──────────────────────────────────────────────────────────────────────
    # Plot 6: Hardware Impairment Summary Table
    # ──────────────────────────────────────────────────────────────────────
    ax = axes[1, 2]
    ax.axis('off')
    
    # Compute summary statistics
    if d_spacings is not None and len(d_spacings) > 0:
        spacing_error_pct = ((d_spacings - d_nominal) / d_nominal) * 100
        max_spacing_err = np.max(np.abs(spacing_error_pct))
        std_spacing_err = np.std(spacing_error_pct)
    else:
        max_spacing_err = 0
        std_spacing_err = 0
    
    best_omega = min(results.keys(), key=lambda w: results[w]['SER'])
    best_ser = results[best_omega]['SER']
    best_pd_for_ser = results[best_omega]['Pd']
    
    # Create summary text
    summary_lines = [
        ('HARDWARE IMPAIRMENT PARAMETERS', '', 'header'),
        ('─' * 40, '', 'separator'),
        ('Antenna Elements (K)', f'{K}', 'data'),
        ('Hardware Impairments', 'Enabled' if enable_hw else 'Disabled', 'data'),
        ('Spacing Perturbation σ_λ', f'λ/30', 'data'),
        ('Max Spacing Error', f'{max_spacing_err:.2f}%', 'data'),
        ('Spacing Error Std', f'{std_spacing_err:.2f}%', 'data'),
        ('─' * 40, '', 'separator'),
        ('OPTIMAL PERFORMANCE', '', 'header'),
        ('─' * 40, '', 'separator'),
        ('Best ω_r for SER', f'{best_omega:.2f}', 'data'),
        ('Best SER achieved', f'{best_ser:.4f}', 'data'),
        ('Pd at best SER', f'{best_pd_for_ser:.3f}', 'data'),
        ('─' * 40, '', 'separator'),
    ]
    
    y_pos = 0.95
    for label, value, style in summary_lines:
        if style == 'header':
            ax.text(0.5, y_pos, label, transform=ax.transAxes, 
                    ha='center', va='top', fontsize=11, fontweight='bold',
                    color=c_accent1)
        elif style == 'separator':
            ax.text(0.5, y_pos, label, transform=ax.transAxes,
                    ha='center', va='top', fontsize=9, color='white', alpha=0.5)
        else:
            ax.text(0.1, y_pos, label, transform=ax.transAxes,
                    ha='left', va='top', fontsize=9, color='white')
            ax.text(0.9, y_pos, value, transform=ax.transAxes,
                    ha='right', va='top', fontsize=9, color=c_accent2, fontweight='bold')
        y_pos -= 0.065
    
    ax.set_title('Summary Statistics', pad=10)
    
    plt.tight_layout()
    plt.savefig(f'{save_path}/hardware_impairment_analysis.png', dpi=150,
                facecolor='#1a1a2e', edgecolor='none', bbox_inches='tight')
    print(f"  ✓ Hardware impairment analysis saved to {save_path}/hardware_impairment_analysis.png")
    
    plt.close()



# ╔════════════════════════════════════════════════════════════════════════════╗
# ║                         MAIN EXECUTION                                     ║
# ╚════════════════════════════════════════════════════════════════════════════╝

def main():
    print("\n" + "╔" + "═" * 68 + "╗")
    print("║" + " " * 15 + "ISAC ADAPTIVE AUTOENCODER" + " " * 28 + "║")
    print("╚" + "═" * 68 + "╝\n")
    
    # ──────────────────────────────────────────────────────────────────────
    # Load Dataset
    # ──────────────────────────────────────────────────────────────────────
    try:
        train_data, test_data, params = load_dataset('isac_data.mat')
    except FileNotFoundError:
        print("═" * 70)
        print("  ERROR: isac_data.mat not found!")
        print("  Please run generate_isac_dataset.m in MATLAB first.")
        print("═" * 70)
        return
    
    K = int(params.K)
    M = int(params.M)
    omega_r_values = list(params.omega_r_values)
    
    print(f"  Dataset loaded:")
    print(f"    • Antennas (K):        {K}")
    print(f"    • Constellation (M):   {M}")
    print(f"    • Training samples:    {len(train_data.m_idx):,}")
    print(f"    • Test samples:        {len(test_data.m_idx):,}")
    print(f"    • ω_r values:          {omega_r_values}")
    
    # ──────────────────────────────────────────────────────────────────────
    # Prepare Data
    # ──────────────────────────────────────────────────────────────────────
    print("\n  Preparing tensors...")
    train_tensors = prepare_tensors(train_data, config.device)
    test_tensors = prepare_tensors(test_data, config.device)
    print("    ✓ Data ready")
    
    # ──────────────────────────────────────────────────────────────────────
    # Create Model
    # ──────────────────────────────────────────────────────────────────────
    model = AdaptiveISACReceiver(K, M).to(config.device)
    print(f"\n  Model created:")
    print(f"    • Parameters: {model.count_parameters():,}")
    print(f"    • Device: {config.device}")
    
    # ──────────────────────────────────────────────────────────────────────
    # Train
    # ──────────────────────────────────────────────────────────────────────
    history = train_model(model, train_tensors, config)
    
    # ──────────────────────────────────────────────────────────────────────
    # Evaluate
    # ──────────────────────────────────────────────────────────────────────
    print("═" * 70)
    print("                         EVALUATION")
    print("═" * 70 + "\n")
    
    results = evaluate(model, test_tensors, omega_r_values)
    
    # Print results
    print("  Results by ω_r:\n")
    print(f"  {'ω_r':>6}  {'SER':>8}  {'Pd':>8}  {'Pfa':>8}  {'RMSE':>8}")
    print("  " + "─" * 46)
    for omega in sorted(results.keys()):
        r = results[omega]
        print(f"  {omega:>6.2f}  {r['SER']:>8.4f}  {r['Pd']:>8.3f}  "
              f"{r['Pfa']:>8.4f}  {r['RMSE_deg']:>7.2f}°")
    
    # ──────────────────────────────────────────────────────────────────────
    # Visualize
    # ──────────────────────────────────────────────────────────────────────
    print("\n" + "═" * 70)
    print("                       GENERATING PLOTS")
    print("═" * 70 + "\n")
    
    plot_results(history, results, config)
    plot_hardware_impairments(params, results)

    # ──────────────────────────────────────────────────────────────────────
    # Save Model
    # ──────────────────────────────────────────────────────────────────────
    Path('models').mkdir(exist_ok=True)
    torch.save(model.state_dict(), 'models/isac_adaptive.pth')
    print(f"  ✓ Model saved to models/isac_adaptive.pth")
    
    print("\n" + "╔" + "═" * 68 + "╗")
    print("║" + " " * 25 + "COMPLETE" + " " * 35 + "║")
    print("╚" + "═" * 68 + "╝\n")


if __name__ == "__main__":
    main()
