%% ============================================================================
%  ISAC System Model & Dataset Generator
%  
%  PURPOSE:
%    This script models a complete Integrated Sensing and Communication (ISAC)
%    system and generates training/test datasets for the neural network-based
%    autoencoder receiver.
%
%  SYSTEM MODEL (from paper):
%    - K-antenna transmitter with ISAC beamforming
%    - 4-QAM communication to single-antenna receiver
%    - Monostatic radar for target detection and angle estimation
%    - Hardware impairments modeled via antenna spacing perturbations
%
%  OUTPUT:
%    isac_data.mat - Contains train/test data with varied omega_r values
%
%  NEXT STEP:
%    Run isac_autoencoder.py to train the neural network receiver
%
% ============================================================================
clc; clear; close all;
rng('default');

fprintf('╔════════════════════════════════════════════════════════════════╗\n');
fprintf('║         ISAC System Model & Dataset Generator                 ║\n');
fprintf('╚════════════════════════════════════════════════════════════════╝\n\n');

%% ========== SYSTEM PARAMETERS ==========
% Based on Section IV.A of the reference paper

% Antenna Configuration
K = 16;                              % Number of antennas
lambda = 0.125;                      % Wavelength (2.4 GHz carrier)
d_nominal = lambda / 2;              % Nominal antenna spacing (λ/2)

% Communication Parameters
M = 4;                               % Constellation size (4-QAM)
Etx = 1;                             % Transmit power constraint

% Angular Ranges
theta_min = deg2rad(-20);            % Target AoA minimum
theta_max = deg2rad(20);             % Target AoA maximum  
vartheta_min = deg2rad(30);          % Comm receiver AoD minimum
vartheta_max = deg2rad(50);          % Comm receiver AoD maximum

% SNR Configuration
SNRc_dB = 20;                        % Communication SNR (dB)
SNRr_dB = 0;                         % Radar SNR (dB)
N0 = 1;                              % Noise power spectral density

% Derived SNR values
sigma_c2 = N0 * 10^(SNRc_dB / 10);   % Channel variance for comm
sigma_r2 = N0 * 10^(SNRr_dB / 10);   % Channel variance for radar

% Dataset Size
numTrainSamples = 500000;            % Training samples
numTestSamples = 50000;              % Test samples
p_target = 0.5;                      % Prior probability of target presence

% Hardware Impairments (Section IV.E)
sigma_lambda = lambda / 30;          % Antenna spacing perturbation std
enable_hardware_impairments = true;  % Enable/disable impairments

% Omega_r values for training diversity (radar power allocation factor)
% The autoencoder will learn to adapt to different omega_r values
omega_r_values = [0.01, 0.03, 0.09, 0.15, 0.4, 0.6, 0.7, 0.9];

%% ========== DISPLAY CONFIGURATION ==========
fprintf('┌─────────────────────────────────────────────────┐\n');
fprintf('│             System Configuration                │\n');
fprintf('├─────────────────────────────────────────────────┤\n');
fprintf('│  Antennas (K):              %-4d               │\n', K);
fprintf('│  Constellation (M):         %-4d               │\n', M);
fprintf('│  Comm SNR:                  %-4.0f dB            │\n', SNRc_dB);
fprintf('│  Radar SNR:                 %-4.0f dB            │\n', SNRr_dB);
fprintf('│  Training samples:          %-7d            │\n', numTrainSamples);
fprintf('│  Test samples:              %-7d            │\n', numTestSamples);
fprintf('│  Hardware impairments:      %-5s              │\n', string(enable_hardware_impairments));
fprintf('└─────────────────────────────────────────────────┘\n\n');

%% ========== ANTENNA ARRAY SETUP ==========
fprintf('Setting up antenna array...\n');
if enable_hardware_impairments
    % Model realistic hardware with perturbed antenna spacings
    d_spacings = d_nominal + sigma_lambda * randn(K-1, 1);
    fprintf('  ✓ Hardware impairments enabled (σ_λ = λ/30)\n');
else
    % Ideal uniform linear array
    d_spacings = d_nominal * ones(K-1, 1);
    fprintf('  ✓ Ideal antenna array (no impairments)\n');
end

%% ========== GENERATE TRAINING DATA ==========
fprintf('\n═══════════════════════════════════════════════════════════════\n');
fprintf('               GENERATING TRAINING DATA                        \n');
fprintf('═══════════════════════════════════════════════════════════════\n');

train = generate_isac_data(numTrainSamples, K, M, ...
    theta_min, theta_max, vartheta_min, vartheta_max, ...
    sigma_r2, sigma_c2, N0, Etx, p_target, ...
    d_spacings, d_nominal, lambda, enable_hardware_impairments, ...
    omega_r_values);

fprintf('  ✓ Training data: %d samples generated\n', numTrainSamples);

%% ========== GENERATE TEST DATA ==========
fprintf('\n═══════════════════════════════════════════════════════════════\n');
fprintf('               GENERATING TEST DATA                            \n');
fprintf('═══════════════════════════════════════════════════════════════\n');

test = generate_isac_data(numTestSamples, K, M, ...
    theta_min, theta_max, vartheta_min, vartheta_max, ...
    sigma_r2, sigma_c2, N0, Etx, p_target, ...
    d_spacings, d_nominal, lambda, enable_hardware_impairments, ...
    omega_r_values);

fprintf('  ✓ Test data: %d samples generated\n', numTestSamples);

%% ========== STORE PARAMETERS ==========
params.K = K;
params.M = M;
params.Etx = Etx;
params.lambda = lambda;
params.d_nominal = d_nominal;
params.d_spacings = d_spacings;
params.theta_min = theta_min;
params.theta_max = theta_max;
params.vartheta_min = vartheta_min;
params.vartheta_max = vartheta_max;
params.SNRc_dB = SNRc_dB;
params.SNRr_dB = SNRr_dB;
params.N0 = N0;
params.sigma_c2 = sigma_c2;
params.sigma_r2 = sigma_r2;
params.p_target = p_target;
params.omega_r_values = omega_r_values;
params.enable_hardware_impairments = enable_hardware_impairments;
params.sigma_lambda = sigma_lambda;

%% ========== SAVE DATASET ==========
fprintf('\n═══════════════════════════════════════════════════════════════\n');
fprintf('               SAVING DATASET                                  \n');
fprintf('═══════════════════════════════════════════════════════════════\n');

save('isac_data.mat', 'train', 'test', 'params', '-v7');
fprintf('  ✓ Dataset saved to: isac_data.mat\n');

%% ========== DATA VISUALIZATION ==========
fprintf('\n═══════════════════════════════════════════════════════════════\n');
fprintf('               DATA VISUALIZATION                              \n');
fprintf('═══════════════════════════════════════════════════════════════\n');

visualize_dataset(train, params);

%% ========== HARDWARE IMPAIRMENT ANALYSIS ==========
fprintf('\n═══════════════════════════════════════════════════════════════\n');
fprintf('               HARDWARE IMPAIRMENT ANALYSIS                    \n');
fprintf('═══════════════════════════════════════════════════════════════\n');

visualize_hardware_impairments(params, train, d_spacings, d_nominal, lambda, K, ...
    theta_min, theta_max, vartheta_min, vartheta_max, omega_r_values);

%% ========== COMPLETION ==========
fprintf('\n╔════════════════════════════════════════════════════════════════╗\n');
fprintf('║                    DATASET GENERATION COMPLETE                ║\n');
fprintf('╠════════════════════════════════════════════════════════════════╣\n');
fprintf('║  Output file: isac_data.mat                                   ║\n');
fprintf('║                                                               ║\n');
fprintf('║  Next step: python isac_autoencoder.py                        ║\n');
fprintf('╚════════════════════════════════════════════════════════════════╝\n');


%% ============================================================================
%                         HELPER FUNCTIONS
% ============================================================================

function data = generate_isac_data(N, K, M, ...
    theta_min, theta_max, vartheta_min, vartheta_max, ...
    sigma_r2, sigma_c2, N0, Etx, p_target, ...
    d_spacings, d_nominal, lambda, enable_hw, omega_r_values)
    %----------------------------------------------------------------------
    % GENERATE_ISAC_DATA: Create ISAC system simulation data
    %
    % This function simulates the complete ISAC system including:
    %   - Random message generation (4-QAM)
    %   - Target presence (Bernoulli with probability p_target)
    %   - Radar channel with target reflection
    %   - Communication channel with fading
    %   - AWGN noise on both channels
    %
    % The omega_r value is randomly selected for each sample to provide
    % training diversity for the adaptive autoencoder.
    %----------------------------------------------------------------------
    
    num_omega_values = length(omega_r_values);
    
    % Pre-allocate data structures
    data.m_idx = randi(M, N, 1);                                    % Message index [1, M]
    data.target_present = double(rand(N, 1) < p_target);            % Target presence {0, 1}
    data.theta_true = theta_min + rand(N, 1) * (theta_max - theta_min);  % Target AoA
    data.vartheta_true = vartheta_min + rand(N, 1) * (vartheta_max - vartheta_min);  % Comm AoD
    data.omega_r = zeros(N, 1);  % Store omega_r used for each sample
    
    % Channel coefficients (complex Gaussian)
    data.alpha = sqrt(sigma_r2/2) * (randn(N, 1) + 1j * randn(N, 1));  % Radar channel
    data.beta = sqrt(sigma_c2/2) * (randn(N, 1) + 1j * randn(N, 1));   % Comm channel
    
    % 4-QAM constellation (normalized)
    qam_constellation = [1+1j, 1-1j, -1+1j, -1-1j] / sqrt(2);
    
    % ISAC beamformer design - use center angles for nominal beamformer
    theta_center = (theta_min + theta_max) / 2;
    vartheta_center = (vartheta_min + vartheta_max) / 2;
    
    % Pre-compute steering vectors for center angles
    if enable_hw
        a_r_center = steering_vector_impaired(theta_center, K, d_spacings, lambda);
        a_c_center = steering_vector_impaired(vartheta_center, K, d_spacings, lambda);
    else
        a_r_center = steering_vector(theta_center, K, d_nominal, lambda);
        a_c_center = steering_vector(vartheta_center, K, d_nominal, lambda);
    end
    
    % Initialize output arrays
    Y_radar = zeros(N, K);
    Y_comm = zeros(N, 1);
    kappa = zeros(N, 1);
    
    % Progress display
    fprintf('  Progress: ');
    progress_step = floor(N / 10);
    
    for n = 1:N
        % Display progress
        if mod(n, progress_step) == 0
            fprintf('█');
        end
        
        % Randomly select omega_r for this sample (training diversity)
        omega_idx = randi(num_omega_values);
        omega_r = omega_r_values(omega_idx);
        data.omega_r(n) = omega_r;
        
        % Design ISAC beamformer for this omega_r
        % v = sqrt(omega_r) * a_r + sqrt(1 - omega_r) * a_c
        v = sqrt(omega_r) * a_r_center + sqrt(1 - omega_r) * a_c_center;
        v = sqrt(Etx) * v / norm(v);  % Normalize to power constraint
        
        % Transmitted symbol
        x = qam_constellation(data.m_idx(n));
        
        % Transmitted signal: y = v * x (K x 1)
        y = v * x;
        
        %------------------------------------------------------------------
        % RADAR CHANNEL
        %------------------------------------------------------------------
        if enable_hw
            a_target = steering_vector_impaired(data.theta_true(n), K, d_spacings, lambda);
        else
            a_target = steering_vector(data.theta_true(n), K, d_nominal, lambda);
        end
        
        % Radar return: z_r = t * alpha * a(theta) * a(theta)^H * y + noise
        inner_product = a_target' * y;
        z_r = data.target_present(n) * data.alpha(n) * a_target * inner_product;
        z_r = z_r + sqrt(N0/2) * (randn(K, 1) + 1j * randn(K, 1));
        Y_radar(n, :) = z_r.';
        
        %------------------------------------------------------------------
        % COMMUNICATION CHANNEL
        %------------------------------------------------------------------
        if enable_hw
            a_comm = steering_vector_impaired(data.vartheta_true(n), K, d_spacings, lambda);
        else
            a_comm = steering_vector(data.vartheta_true(n), K, d_nominal, lambda);
        end
        
        % Effective channel coefficient (CSI)
        kappa(n) = data.beta(n) * (a_comm' * v);
        
        % Received signal: z_c = kappa * x + noise
        z_c = kappa(n) * x;
        z_c = z_c + sqrt(N0/2) * (randn + 1j * randn);
        Y_comm(n) = z_c;
    end
    
    fprintf(' Done!\n');
    
    % Store outputs
    data.Y_radar = Y_radar;
    data.Y_comm = Y_comm;
    data.kappa = kappa;
end


function a = steering_vector(theta, K, d, lambda)
    %----------------------------------------------------------------------
    % STEERING_VECTOR: Ideal uniform linear array steering vector
    %
    % Input:
    %   theta  - Angle of arrival/departure [rad]
    %   K      - Number of antennas
    %   d      - Antenna spacing [m]
    %   lambda - Wavelength [m]
    %
    % Output:
    %   a      - K x 1 complex steering vector
    %----------------------------------------------------------------------
    n = (0:K-1).';
    a = exp(-1j * 2 * pi * n * (d / lambda) * sin(theta));
end


function a = steering_vector_impaired(theta, K, d_spacings, lambda)
    %----------------------------------------------------------------------
    % STEERING_VECTOR_IMPAIRED: Steering vector with hardware impairments
    %
    % Models non-uniform antenna spacings due to manufacturing tolerances
    %
    % Input:
    %   theta      - Angle of arrival/departure [rad]
    %   K          - Number of antennas
    %   d_spacings - (K-1) x 1 vector of inter-element spacings
    %   lambda     - Wavelength [m]
    %
    % Output:
    %   a          - K x 1 complex steering vector
    %----------------------------------------------------------------------
    positions = [0; cumsum(d_spacings)];
    a = exp(-1j * 2 * pi / lambda * positions * sin(theta));
end


function visualize_dataset(data, params)
    %----------------------------------------------------------------------
    % VISUALIZE_DATASET: Create diagnostic plots for the generated data
    %----------------------------------------------------------------------
    
    figure('Name', 'ISAC Dataset Visualization', 'Position', [100, 100, 1200, 500]);
    
    % Plot 1: Received Constellation (Communication)
    subplot(1, 3, 1);
    scatter(real(data.Y_comm), imag(data.Y_comm), 5, 'b', 'filled', 'MarkerFaceAlpha', 0.1);
    hold on;
    % Ideal constellation points
    qam = [1+1j, 1-1j, -1+1j, -1-1j] / sqrt(2);
    scatter(real(qam), imag(qam), 100, 'r', 'x', 'LineWidth', 3);
    hold off;
    grid on;
    xlabel('In-Phase');
    ylabel('Quadrature');
    title('Received Constellation (Comm)');
    legend('Received', 'Ideal 4-QAM', 'Location', 'best');
    axis equal;
    xlim([-3, 3]); ylim([-3, 3]);
    
    % Plot 2: Target Angle Distribution
    subplot(1, 3, 2);
    histogram(rad2deg(data.theta_true), 40, 'FaceColor', [0.2, 0.6, 0.8], 'EdgeColor', 'none');
    hold on;
    xline(rad2deg(params.theta_min), 'r--', 'LineWidth', 2);
    xline(rad2deg(params.theta_max), 'r--', 'LineWidth', 2);
    hold off;
    grid on;
    xlabel('Target Angle (degrees)');
    ylabel('Count');
    title('Target AoA Distribution');
    
    % Plot 3: Omega_r Distribution
    subplot(1, 3, 3);
    histogram(data.omega_r, 'FaceColor', [0.8, 0.4, 0.2], 'EdgeColor', 'none');
    grid on;
    xlabel('\omega_r (Radar Allocation Factor)');
    ylabel('Count');
    title('Training \omega_r Distribution');
    
    % Save figure
    saveas(gcf, 'dataset_visualization.png');
    fprintf('  ✓ Visualization saved to: dataset_visualization.png\n');
end


function visualize_hardware_impairments(params, data, d_spacings, d_nominal, lambda, K, ...
    theta_min, theta_max, vartheta_min, vartheta_max, omega_r_values)
    %----------------------------------------------------------------------
    % VISUALIZE_HARDWARE_IMPAIRMENTS: Comprehensive analysis of hardware
    % impairment effects on ISAC system performance
    %
    % Creates a 2x3 figure showing:
    % 1. Antenna spacing distribution (actual vs nominal)
    % 2. Array geometry visualization
    % 3. Beampattern comparison (ideal vs impaired)
    % 4. Phase error across antennas
    % 5. SNR degradation vs omega_r
    % 6. Constellation scatter comparison
    %----------------------------------------------------------------------
    
    figure('Name', 'Hardware Impairment Analysis', 'Position', [50, 50, 1400, 800], ...
           'Color', [0.1, 0.1, 0.15]);
    
    % Color scheme for dark theme
    colors.background = [0.1, 0.1, 0.15];
    colors.axes = [0.15, 0.15, 0.2];
    colors.text = [0.95, 0.95, 0.95];
    colors.grid = [0.3, 0.3, 0.35];
    colors.ideal = [0.2, 0.8, 0.4];      % Green
    colors.impaired = [0.9, 0.3, 0.3];   % Red
    colors.accent1 = [0.3, 0.6, 0.9];    % Blue
    colors.accent2 = [0.9, 0.6, 0.2];    % Orange
    
    %----------------------------------------------------------------------
    % Plot 1: Antenna Spacing Distribution
    %----------------------------------------------------------------------
    subplot(2, 3, 1);
    set(gca, 'Color', colors.axes);
    
    spacing_error_percent = ((d_spacings - d_nominal) / d_nominal) * 100;
    
    bar(1:K-1, spacing_error_percent, 'FaceColor', colors.accent1, 'EdgeColor', 'none');
    hold on;
    yline(0, 'Color', colors.ideal, 'LineWidth', 2, 'LineStyle', '--');
    yline(mean(spacing_error_percent), 'Color', colors.impaired, 'LineWidth', 1.5, ...
          'Label', sprintf('Mean: %.2f%%', mean(spacing_error_percent)));
    hold off;
    
    xlabel('Antenna Pair Index', 'Color', colors.text);
    ylabel('Spacing Error (%)', 'Color', colors.text);
    title('Antenna Spacing Perturbations', 'Color', colors.text, 'FontWeight', 'bold');
    grid on;
    set(gca, 'XColor', colors.text, 'YColor', colors.text, 'GridColor', colors.grid);
    xlim([0, K]);
    
    % Add statistics annotation
    stats_str = sprintf('σ_λ = λ/30\nStd: %.2f%%\nMax: %.2f%%', ...
                        std(spacing_error_percent), max(abs(spacing_error_percent)));
    text(0.98, 0.95, stats_str, 'Units', 'normalized', 'HorizontalAlignment', 'right', ...
         'VerticalAlignment', 'top', 'Color', colors.text, 'FontSize', 9, ...
         'BackgroundColor', [0.2, 0.2, 0.25], 'EdgeColor', colors.accent1);
    
    %----------------------------------------------------------------------
    % Plot 2: Array Geometry Visualization
    %----------------------------------------------------------------------
    subplot(2, 3, 2);
    set(gca, 'Color', colors.axes);
    
    % Ideal positions
    ideal_positions = (0:K-1) * d_nominal;
    % Impaired positions
    impaired_positions = [0; cumsum(d_spacings)];
    
    % Normalize for display
    ideal_norm = ideal_positions / lambda;
    impaired_norm = impaired_positions / lambda;
    
    plot(ideal_norm, zeros(K, 1), 'o', 'MarkerSize', 12, 'MarkerFaceColor', colors.ideal, ...
         'MarkerEdgeColor', 'white', 'LineWidth', 1.5, 'DisplayName', 'Ideal');
    hold on;
    plot(impaired_norm, 0.3*ones(K, 1), 's', 'MarkerSize', 10, 'MarkerFaceColor', colors.impaired, ...
         'MarkerEdgeColor', 'white', 'LineWidth', 1.5, 'DisplayName', 'Impaired');
    
    % Draw connecting lines showing deviation
    for k = 1:K
        plot([ideal_norm(k), impaired_norm(k)], [0, 0.3], ':', 'Color', colors.accent2, 'LineWidth', 1);
    end
    hold off;
    
    xlabel('Position (wavelengths)', 'Color', colors.text);
    ylabel('Array Type', 'Color', colors.text);
    title('Array Geometry Comparison', 'Color', colors.text, 'FontWeight', 'bold');
    legend('Location', 'southeast', 'TextColor', colors.text, 'Color', [0.15, 0.15, 0.2]);
    set(gca, 'XColor', colors.text, 'YColor', colors.text, 'GridColor', colors.grid);
    set(gca, 'YTick', [0, 0.3], 'YTickLabel', {'Ideal', 'Impaired'});
    ylim([-0.2, 0.5]);
    grid on;
    
    %----------------------------------------------------------------------
    % Plot 3: Beampattern Comparison
    %----------------------------------------------------------------------
    subplot(2, 3, 3);
    set(gca, 'Color', colors.axes);
    
    % Compute beampatterns
    theta_scan = linspace(-90, 90, 361);
    theta_steer = 0;  % Steering towards broadside
    
    % Ideal beampattern
    beampattern_ideal = zeros(1, length(theta_scan));
    a_steer_ideal = steering_vector(deg2rad(theta_steer), K, d_nominal, lambda);
    
    for i = 1:length(theta_scan)
        a_scan = steering_vector(deg2rad(theta_scan(i)), K, d_nominal, lambda);
        beampattern_ideal(i) = abs(a_scan' * a_steer_ideal)^2;
    end
    
    % Impaired beampattern
    beampattern_impaired = zeros(1, length(theta_scan));
    a_steer_impaired = steering_vector_impaired(deg2rad(theta_steer), K, d_spacings, lambda);
    
    for i = 1:length(theta_scan)
        a_scan = steering_vector_impaired(deg2rad(theta_scan(i)), K, d_spacings, lambda);
        beampattern_impaired(i) = abs(a_scan' * a_steer_impaired)^2;
    end
    
    % Normalize
    beampattern_ideal_dB = 10*log10(beampattern_ideal / max(beampattern_ideal) + 1e-10);
    beampattern_impaired_dB = 10*log10(beampattern_impaired / max(beampattern_impaired) + 1e-10);
    
    plot(theta_scan, beampattern_ideal_dB, 'Color', colors.ideal, 'LineWidth', 2, ...
         'DisplayName', 'Ideal ULA');
    hold on;
    plot(theta_scan, beampattern_impaired_dB, 'Color', colors.impaired, 'LineWidth', 2, ...
         'DisplayName', 'Impaired');
    
    % Mark target and comm regions
    xregion([rad2deg(theta_min), rad2deg(theta_max)], 'FaceColor', colors.accent1, 'FaceAlpha', 0.2);
    xregion([rad2deg(vartheta_min), rad2deg(vartheta_max)], 'FaceColor', colors.accent2, 'FaceAlpha', 0.2);
    hold off;
    
    xlabel('Angle (degrees)', 'Color', colors.text);
    ylabel('Normalized Pattern (dB)', 'Color', colors.text);
    title('Beampattern Comparison', 'Color', colors.text, 'FontWeight', 'bold');
    legend('Ideal', 'Impaired', 'Radar Region', 'Comm Region', ...
           'Location', 'southwest', 'TextColor', colors.text, 'Color', [0.15, 0.15, 0.2]);
    set(gca, 'XColor', colors.text, 'YColor', colors.text, 'GridColor', colors.grid);
    xlim([-90, 90]);
    ylim([-40, 5]);
    grid on;
    
    %----------------------------------------------------------------------
    % Plot 4: Phase Error Across Antennas
    %----------------------------------------------------------------------
    subplot(2, 3, 4);
    set(gca, 'Color', colors.axes);
    
    % Calculate phase error at a specific angle
    test_angle = deg2rad(10);  % 10 degrees
    
    a_ideal = steering_vector(test_angle, K, d_nominal, lambda);
    a_impaired = steering_vector_impaired(test_angle, K, d_spacings, lambda);
    
    phase_ideal = rad2deg(angle(a_ideal));
    phase_impaired = rad2deg(angle(a_impaired));
    phase_error = phase_impaired - phase_ideal;
    
    % Unwrap phase error
    phase_error = wrapTo180(phase_error);
    
    bar(1:K, phase_error, 'FaceColor', colors.accent2, 'EdgeColor', 'none');
    hold on;
    yline(0, 'Color', 'white', 'LineWidth', 1.5, 'LineStyle', '--');
    hold off;
    
    xlabel('Antenna Index', 'Color', colors.text);
    ylabel('Phase Error (degrees)', 'Color', colors.text);
    title(sprintf('Phase Error at θ = %.0f°', rad2deg(test_angle)), 'Color', colors.text, 'FontWeight', 'bold');
    set(gca, 'XColor', colors.text, 'YColor', colors.text, 'GridColor', colors.grid);
    grid on;
    
    % Add RMS annotation
    rms_error = sqrt(mean(phase_error.^2));
    text(0.98, 0.95, sprintf('RMS: %.2f°', rms_error), 'Units', 'normalized', ...
         'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
         'Color', colors.text, 'FontSize', 10, 'FontWeight', 'bold', ...
         'BackgroundColor', [0.2, 0.2, 0.25], 'EdgeColor', colors.accent2);
    
    %----------------------------------------------------------------------
    % Plot 5: Effective SNR vs Omega_r
    %----------------------------------------------------------------------
    subplot(2, 3, 5);
    set(gca, 'Color', colors.axes);
    
    % Calculate effective SNR for each omega_r value
    effective_snr_comm = zeros(length(omega_r_values), 1);
    effective_snr_radar = zeros(length(omega_r_values), 1);
    
    theta_c = (theta_min + theta_max) / 2;
    vartheta_c = (vartheta_min + vartheta_max) / 2;
    
    a_r = steering_vector_impaired(theta_c, K, d_spacings, lambda);
    a_c = steering_vector_impaired(vartheta_c, K, d_spacings, lambda);
    
    for i = 1:length(omega_r_values)
        omega_r = omega_r_values(i);
        
        % Beamformer
        v = sqrt(omega_r) * a_r + sqrt(1 - omega_r) * a_c;
        v = v / norm(v);
        
        % Effective gains
        gain_radar = abs(a_r' * v)^2;
        gain_comm = abs(a_c' * v)^2;
        
        effective_snr_radar(i) = 10*log10(K * gain_radar);
        effective_snr_comm(i) = 10*log10(gain_comm);
    end
    
    yyaxis left;
    plot(omega_r_values, effective_snr_comm, '-o', 'Color', colors.accent1, ...
         'LineWidth', 2, 'MarkerFaceColor', colors.accent1, 'MarkerSize', 8);
    ylabel('Comm Gain (dB)', 'Color', colors.accent1);
    set(gca, 'YColor', colors.accent1);
    
    yyaxis right;
    plot(omega_r_values, effective_snr_radar, '-s', 'Color', colors.accent2, ...
         'LineWidth', 2, 'MarkerFaceColor', colors.accent2, 'MarkerSize', 8);
    ylabel('Radar Gain (dB)', 'Color', colors.accent2);
    set(gca, 'YColor', colors.accent2);
    
    xlabel('\omega_r (Radar Allocation)', 'Color', colors.text);
    title('Effective Beamforming Gain vs \omega_r', 'Color', colors.text, 'FontWeight', 'bold');
    set(gca, 'XColor', colors.text, 'GridColor', colors.grid, 'Color', colors.axes);
    grid on;
    legend('Comm Gain', 'Radar Gain', 'Location', 'east', ...
           'TextColor', colors.text, 'Color', [0.15, 0.15, 0.2]);
    
    %----------------------------------------------------------------------
    % Plot 6: Impact Summary Table
    %----------------------------------------------------------------------
    subplot(2, 3, 6);
    set(gca, 'Color', colors.axes);
    axis off;
    
    % Compute metrics
    position_error_mm = (impaired_positions - ideal_positions') * 1000;
    max_pos_error = max(abs(position_error_mm));
    
    % Create summary text
    title_text = 'Hardware Impairment Summary';
    
    summary_lines = {
        sprintf('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        sprintf('Parameter             Value');
        sprintf('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        sprintf('Antenna Elements:     %d', K);
        sprintf('Wavelength:           %.3f m', lambda);
        sprintf('Nominal Spacing:      λ/2 (%.4f m)', d_nominal);
        sprintf('Perturbation σ_λ:     λ/30 (%.5f m)', params.sigma_lambda);
        sprintf('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        sprintf('Spacing Error Std:    %.3f%%', std(spacing_error_percent));
        sprintf('Max Spacing Error:    %.3f%%', max(abs(spacing_error_percent)));
        sprintf('Max Position Error:   %.3f mm', max_pos_error);
        sprintf('RMS Phase Error:      %.2f°', rms_error);
        sprintf('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    };
    
    text(0.5, 0.95, title_text, 'Units', 'normalized', 'HorizontalAlignment', 'center', ...
         'VerticalAlignment', 'top', 'Color', colors.accent1, 'FontSize', 12, 'FontWeight', 'bold');
    
    for i = 1:length(summary_lines)
        text(0.1, 0.88 - (i-1)*0.07, summary_lines{i}, 'Units', 'normalized', ...
             'Color', colors.text, 'FontSize', 9, 'FontName', 'Consolas');
    end
    
    %----------------------------------------------------------------------
    % Add overall title
    %----------------------------------------------------------------------
    sgtitle('ISAC System Hardware Impairment Analysis', 'Color', colors.text, ...
            'FontSize', 14, 'FontWeight', 'bold');
    
    % Save figure
    saveas(gcf, 'hardware_impairment_analysis.png');
    fprintf('  ✓ Hardware impairment analysis saved to: hardware_impairment_analysis.png\n');
end

