%% ============================================================================
%  ISAC System Model & Dataset Generator
%  
%  PURPOSE:
%    This script models a complete Integrated Sensing and Communication (ISAC)
%    system and generates training/test datasets for the neural network-based
%    autoencoder receiver.
%
%  SYSTEM MODEL (from paper):
%    - K-antenna transmitter with ISAC beamforming
%    - 4-QAM communication to single-antenna receiver
%    - Monostatic radar for target detection and angle estimation
%    - Hardware impairments modeled via antenna spacing perturbations
%
%  OUTPUT:
%    isac_data.mat - Contains train/test data with varied omega_r values
%
%  NEXT STEP:
%    Run isac_autoencoder.py to train the neural network receiver
%
% ============================================================================
clc; clear; close all;
rng('default');

fprintf('╔════════════════════════════════════════════════════════════════╗\n');
fprintf('║         ISAC System Model & Dataset Generator                 ║\n');
fprintf('╚════════════════════════════════════════════════════════════════╝\n\n');

%% ========== SYSTEM PARAMETERS ==========
% Based on Section IV.A of the reference paper

% Antenna Configuration
K = 16;                              % Number of antennas
lambda = 0.125;                      % Wavelength (2.4 GHz carrier)
d_nominal = lambda / 2;              % Nominal antenna spacing (λ/2)

% Communication Parameters
M = 4;                               % Constellation size (4-QAM)
Etx = 1;                             % Transmit power constraint

% Angular Ranges
theta_min = deg2rad(-20);            % Target AoA minimum
theta_max = deg2rad(20);             % Target AoA maximum  
vartheta_min = deg2rad(30);          % Comm receiver AoD minimum
vartheta_max = deg2rad(50);          % Comm receiver AoD maximum

% SNR Configuration
SNRc_dB = 20;                        % Communication SNR (dB)
SNRr_dB = 0;                         % Radar SNR (dB)
N0 = 1;                              % Noise power spectral density

% Derived SNR values
sigma_c2 = N0 * 10^(SNRc_dB / 10);   % Channel variance for comm
sigma_r2 = N0 * 10^(SNRr_dB / 10);   % Channel variance for radar

% Dataset Size
numTrainSamples = 500000;            % Training samples
numTestSamples = 50000;              % Test samples
p_target = 0.5;                      % Prior probability of target presence

% Hardware Impairments (Section IV.E)
sigma_lambda = lambda / 30;          % Antenna spacing perturbation std
enable_hardware_impairments = true;  % Enable/disable impairments

% Omega_r values for training diversity (radar power allocation factor)
% The autoencoder will learn to adapt to different omega_r values
omega_r_values = [0.01, 0.03, 0.09, 0.15, 0.4, 0.6, 0.7, 0.9];

%% ========== DISPLAY CONFIGURATION ==========
fprintf('┌─────────────────────────────────────────────────┐\n');
fprintf('│             System Configuration                │\n');
fprintf('├─────────────────────────────────────────────────┤\n');
fprintf('│  Antennas (K):              %-4d               │\n', K);
fprintf('│  Constellation (M):         %-4d               │\n', M);
fprintf('│  Comm SNR:                  %-4.0f dB            │\n', SNRc_dB);
fprintf('│  Radar SNR:                 %-4.0f dB            │\n', SNRr_dB);
fprintf('│  Training samples:          %-7d            │\n', numTrainSamples);
fprintf('│  Test samples:              %-7d            │\n', numTestSamples);
fprintf('│  Hardware impairments:      %-5s              │\n', string(enable_hardware_impairments));
fprintf('└─────────────────────────────────────────────────┘\n\n');

%% ========== ANTENNA ARRAY SETUP ==========
fprintf('Setting up antenna array...\n');
if enable_hardware_impairments
    % Model realistic hardware with perturbed antenna spacings
    d_spacings = d_nominal + sigma_lambda * randn(K-1, 1);
    fprintf('  ✓ Hardware impairments enabled (σ_λ = λ/30)\n');
else
    % Ideal uniform linear array
    d_spacings = d_nominal * ones(K-1, 1);
    fprintf('  ✓ Ideal antenna array (no impairments)\n');
end

%% ========== GENERATE TRAINING DATA(98-106 & 112-119) ==========
fprintf('\n═══════════════════════════════════════════════════════════════\n');
fprintf('               GENERATING TRAINING DATA                        \n');
fprintf('═══════════════════════════════════════════════════════════════\n');

train = generate_isac_data(numTrainSamples, K, M, ...
    theta_min, theta_max, vartheta_min, vartheta_max, ...
    sigma_r2, sigma_c2, N0, Etx, p_target, ...
    d_spacings, d_nominal, lambda, enable_hardware_impairments, ...
    omega_r_values);

fprintf('  ✓ Training data: %d samples generated\n', numTrainSamples);

%% ========== GENERATE TEST DATA ==========
fprintf('\n═══════════════════════════════════════════════════════════════\n');
fprintf('               GENERATING TEST DATA                            \n');
fprintf('═══════════════════════════════════════════════════════════════\n');

test = generate_isac_data(numTestSamples, K, M, ...
    theta_min, theta_max, vartheta_min, vartheta_max, ...
    sigma_r2, sigma_c2, N0, Etx, p_target, ...
    d_spacings, d_nominal, lambda, enable_hardware_impairments, ...
    omega_r_values);

fprintf('  ✓ Test data: %d samples generated\n', numTestSamples);

%% ========== STORE PARAMETERS ==========
params.K = K;
params.M = M;
params.Etx = Etx;
params.lambda = lambda;
params.d_nominal = d_nominal;
params.d_spacings = d_spacings;
params.theta_min = theta_min;
params.theta_max = theta_max;
params.vartheta_min = vartheta_min;
params.vartheta_max = vartheta_max;
params.SNRc_dB = SNRc_dB;
params.SNRr_dB = SNRr_dB;
params.N0 = N0;
params.sigma_c2 = sigma_c2;
params.sigma_r2 = sigma_r2;
params.p_target = p_target;
params.omega_r_values = omega_r_values;
params.enable_hardware_impairments = enable_hardware_impairments;
params.sigma_lambda = sigma_lambda;

%% ========== SAVE DATASET ==========
fprintf('\n═══════════════════════════════════════════════════════════════\n');
fprintf('               SAVING DATASET                                  \n');
fprintf('═══════════════════════════════════════════════════════════════\n');

save('isac_data.mat', 'train', 'test', 'params', '-v7');
fprintf('  ✓ Dataset saved to: isac_data.mat\n');

%% ========== DATA VISUALIZATION ==========
fprintf('\n═══════════════════════════════════════════════════════════════\n');
fprintf('               DATA VISUALIZATION                              \n');
fprintf('═══════════════════════════════════════════════════════════════\n');

visualize_dataset(train, params);

%% ========== HARDWARE IMPAIRMENT ANALYSIS ==========
fprintf('\n═══════════════════════════════════════════════════════════════\n');
fprintf('               HARDWARE IMPAIRMENT ANALYSIS                    \n');
fprintf('═══════════════════════════════════════════════════════════════\n');

visualize_hardware_impairments(params, train, d_spacings, d_nominal, lambda, K, ...
    theta_min, theta_max, vartheta_min, vartheta_max, omega_r_values);

%% ========== COMPLETION ==========
fprintf('\n╔════════════════════════════════════════════════════════════════╗\n');
fprintf('║                    DATASET GENERATION COMPLETE                ║\n');
fprintf('╠════════════════════════════════════════════════════════════════╣\n');
fprintf('║  Output file: isac_data.mat                                   ║\n');
fprintf('║                                                               ║\n');
fprintf('║  Next step: python isac_autoencoder.py                        ║\n');
fprintf('╚════════════════════════════════════════════════════════════════╝\n');


%% ============================================================================
%                         HELPER FUNCTIONS
% ============================================================================

function data = generate_isac_data(N, K, M, ...
    theta_min, theta_max, vartheta_min, vartheta_max, ...
    sigma_r2, sigma_c2, N0, Etx, p_target, ...
    d_spacings, d_nominal, lambda, enable_hw, omega_r_values)
    %----------------------------------------------------------------------
    % GENERATE_ISAC_DATA: Create ISAC system simulation data
    %
    % This function simulates the complete ISAC system including:
    %   - Random message generation (4-QAM)
    %   - Target presence (Bernoulli with probability p_target)
    %   - Radar channel with target reflection
    %   - Communication channel with fading
    %   - AWGN noise on both channels
    %
    % The omega_r value is randomly selected for each sample to provide
    % training diversity for the adaptive autoencoder.
    %----------------------------------------------------------------------
    
    num_omega_values = length(omega_r_values);
    
    % Pre-allocate data structures
    data.m_idx = randi(M, N, 1);                                    % Message index [1, M]
    data.target_present = double(rand(N, 1) < p_target);            % Target presence {0, 1}
    data.theta_true = theta_min + rand(N, 1) * (theta_max - theta_min);  % Target AoA
    data.vartheta_true = vartheta_min + rand(N, 1) * (vartheta_max - vartheta_min);  % Comm AoD
    data.omega_r = zeros(N, 1);  % Store omega_r used for each sample
    
    % Channel coefficients (complex Gaussian)
    data.alpha = sqrt(sigma_r2/2) * (randn(N, 1) + 1j * randn(N, 1));  % Radar channel
    data.beta = sqrt(sigma_c2/2) * (randn(N, 1) + 1j * randn(N, 1));   % Comm channel
    
    % 4-QAM constellation (normalized)
    qam_constellation = [1+1j, 1-1j, -1+1j, -1-1j] / sqrt(2);
    
    % ISAC beamformer design - use center angles for nominal beamformer
    theta_center = (theta_min + theta_max) / 2;
    vartheta_center = (vartheta_min + vartheta_max) / 2;
    
    % Pre-compute steering vectors for center angles
    if enable_hw
        a_r_center = steering_vector_impaired(theta_center, K, d_spacings, lambda);
        a_c_center = steering_vector_impaired(vartheta_center, K, d_spacings, lambda);
    else
        a_r_center = steering_vector(theta_center, K, d_nominal, lambda);
        a_c_center = steering_vector(vartheta_center, K, d_nominal, lambda);
    end
    
    % Initialize output arrays
    Y_radar = zeros(N, K);
    Y_comm = zeros(N, 1);
    kappa = zeros(N, 1);
    
    % Progress display
    fprintf('  Progress: ');
    progress_step = floor(N / 10);
    
    for n = 1:N
        % Display progress
        if mod(n, progress_step) == 0
            fprintf('█');
        end
        
        % Randomly select omega_r for this sample (training diversity)
        omega_idx = randi(num_omega_values);
        omega_r = omega_r_values(omega_idx);
        data.omega_r(n) = omega_r;
        
        % Design ISAC beamformer for this omega_r
        % v = sqrt(omega_r) * a_r + sqrt(1 - omega_r) * a_c
        v = sqrt(omega_r) * a_r_center + sqrt(1 - omega_r) * a_c_center;
        v = sqrt(Etx) * v / norm(v);  % Normalize to power constraint
        
        % Transmitted symbol
        x = qam_constellation(data.m_idx(n));
        
        % Transmitted signal: y = v * x (K x 1)
        y = v * x;
        
        %------------------------------------------------------------------
        % RADAR CHANNEL
        %------------------------------------------------------------------
        if enable_hw
            a_target = steering_vector_impaired(data.theta_true(n), K, d_spacings, lambda);
        else
            a_target = steering_vector(data.theta_true(n), K, d_nominal, lambda);
        end
        
        % Radar return: z_r = t * alpha * a(theta) * a(theta)^H * y + noise
        inner_product = a_target' * y;
        z_r = data.target_present(n) * data.alpha(n) * a_target * inner_product;
        z_r = z_r + sqrt(N0/2) * (randn(K, 1) + 1j * randn(K, 1));
        Y_radar(n, :) = z_r.';
        
        %------------------------------------------------------------------
        % COMMUNICATION CHANNEL
        %------------------------------------------------------------------
        if enable_hw
            a_comm = steering_vector_impaired(data.vartheta_true(n), K, d_spacings, lambda);
        else
            a_comm = steering_vector(data.vartheta_true(n), K, d_nominal, lambda);
        end
        
        % Effective channel coefficient (CSI)
        kappa(n) = data.beta(n) * (a_comm' * v);
        
        % Received signal: z_c = kappa * x + noise
        z_c = kappa(n) * x;
        z_c = z_c + sqrt(N0/2) * (randn + 1j * randn);
        Y_comm(n) = z_c;
    end
    
    fprintf(' Done!\n');
    
    % Store outputs
    data.Y_radar = Y_radar;
    data.Y_comm = Y_comm;
    data.kappa = kappa;
end


function a = steering_vector(theta, K, d, lambda)
    %----------------------------------------------------------------------
    % STEERING_VECTOR: Ideal uniform linear array steering vector
    %
    % Input:
    %   theta  - Angle of arrival/departure [rad]
    %   K      - Number of antennas
    %   d      - Antenna spacing [m]
    %   lambda - Wavelength [m]
    %
    % Output:
    %   a      - K x 1 complex steering vector
    %----------------------------------------------------------------------
    n = (0:K-1).';
    a = exp(-1j * 2 * pi * n * (d / lambda) * sin(theta));
end


function a = steering_vector_impaired(theta, K, d_spacings, lambda)
    %----------------------------------------------------------------------
    % STEERING_VECTOR_IMPAIRED: Steering vector with hardware impairments
    %
    % Models non-uniform antenna spacings due to manufacturing tolerances
    %
    % Input:
    %   theta      - Angle of arrival/departure [rad]
    %   K          - Number of antennas
    %   d_spacings - (K-1) x 1 vector of inter-element spacings
    %   lambda     - Wavelength [m]
    %
    % Output:
    %   a          - K x 1 complex steering vector
    %----------------------------------------------------------------------
    positions = [0; cumsum(d_spacings)];
    a = exp(-1j * 2 * pi / lambda * positions * sin(theta));
end


function visualize_dataset(data, params)
    %----------------------------------------------------------------------
    % VISUALIZE_DATASET: Create diagnostic plots for the generated data
    %----------------------------------------------------------------------
    
    figure('Name', 'ISAC Dataset Visualization', 'Position', [100, 100, 1200, 500]);
    
    % Plot 1: Received Constellation (Communication)
    subplot(1, 3, 1);
    scatter(real(data.Y_comm), imag(data.Y_comm), 5, 'b', 'filled', 'MarkerFaceAlpha', 0.1);
    hold on;
    % Ideal constellation points
    qam = [1+1j, 1-1j, -1+1j, -1-1j] / sqrt(2);
    scatter(real(qam), imag(qam), 100, 'r', 'x', 'LineWidth', 3);
    hold off;
    grid on;
    xlabel('In-Phase');
    ylabel('Quadrature');
    title('Received Constellation (Comm)');
    legend('Received', 'Ideal 4-QAM', 'Location', 'best');
    axis equal;
    xlim([-3, 3]); ylim([-3, 3]);
    
    % Plot 2: Target Angle Distribution
    subplot(1, 3, 2);
    histogram(rad2deg(data.theta_true), 40, 'FaceColor', [0.2, 0.6, 0.8], 'EdgeColor', 'none');
    hold on;
    xline(rad2deg(params.theta_min), 'r--', 'LineWidth', 2);
    xline(rad2deg(params.theta_max), 'r--', 'LineWidth', 2);
    hold off;
    grid on;
    xlabel('Target Angle (degrees)');
    ylabel('Count');
    title('Target AoA Distribution');
    
    % Plot 3: Omega_r Distribution
    subplot(1, 3, 3);
    histogram(data.omega_r, 'FaceColor', [0.8, 0.4, 0.2], 'EdgeColor', 'none');
    grid on;
    xlabel('\omega_r (Radar Allocation Factor)');
    ylabel('Count');
    title('Training \omega_r Distribution');
    
    % Save figure
    saveas(gcf, 'dataset_visualization.png');
    fprintf('  ✓ Visualization saved to: dataset_visualization.png\n');
end


function visualize_hardware_impairments(params, data, d_spacings, d_nominal, lambda, K, ...
    theta_min, theta_max, vartheta_min, vartheta_max, omega_r_values)
    %----------------------------------------------------------------------
    % VISUALIZE_HARDWARE_IMPAIRMENTS: Comprehensive analysis of hardware
    % impairment effects on ISAC system performance
    %
    % Creates a 2x3 figure showing:
    % 1. Antenna spacing distribution (actual vs nominal)
    % 2. Array geometry visualization
    % 3. Beampattern comparison (ideal vs impaired)
    % 4. Phase error across antennas
    % 5. SNR degradation vs omega_r
    % 6. Constellation scatter comparison
    %----------------------------------------------------------------------
    
    % Create output folder for individual plots
    if ~exist('hardware_analysis', 'dir')
        mkdir('hardware_analysis');
    end
    
    % Color scheme for light/white theme (presentation-friendly)
    colors.background = [1, 1, 1];           % White
    colors.axes = [1, 1, 1];                 % White
    colors.text = [0.1, 0.1, 0.1];           % Dark gray/black
    colors.grid = [0.85, 0.85, 0.85];        % Light gray
    colors.ideal = [0.0, 0.5, 0.3];          % Dark Green
    colors.actual = [0.8, 0.2, 0.2];         % Red for actual/impaired
    colors.accent1 = [0.2, 0.4, 0.8];        % Blue
    colors.accent2 = [0.9, 0.5, 0.1];        % Orange
    
    % Pre-compute common values
    spacing_error_percent = ((d_spacings - d_nominal) / d_nominal) * 100;
    ideal_positions = (0:K-1) * d_nominal;
    impaired_positions = [0; cumsum(d_spacings)];
    
    %======================================================================
    % PLOT 1: Antenna Spacing Comparison (Ideal vs Actual) - Side by Side
    %======================================================================
    fig1 = figure('Name', 'Antenna Spacing Comparison', 'Position', [50, 50, 1200, 450], ...
                  'Color', 'white');
    set(gcf, 'InvertHardcopy', 'off');
    sgtitle('Antenna Spacing Analysis: Ideal vs Hardware Impaired', 'FontSize', 14, 'FontWeight', 'bold');
    
    % LHS: Ideal spacing
    subplot(1, 2, 1);
    bar(1:K-1, zeros(K-1, 1), 'FaceColor', colors.ideal, 'EdgeColor', 'none');
    hold on;
    yline(0, 'k-', 'LineWidth', 1.5);
    hold off;
    xlabel('Antenna Pair Index', 'Color', colors.text);
    ylabel('Spacing Error (%)', 'Color', colors.text);
    title('IDEAL: Uniform Linear Array', 'Color', colors.ideal, 'FontWeight', 'bold');
    ylim([-30, 30]);
    grid on;
    set(gca, 'XColor', colors.text, 'YColor', colors.text, 'GridColor', colors.grid);
    text(0.5, 0.9, {'Perfect spacing', 'No perturbations'}, 'Units', 'normalized', ...
         'HorizontalAlignment', 'center', 'FontAngle', 'italic', 'FontSize', 10, ...
         'BackgroundColor', [0.9, 0.95, 0.9], 'EdgeColor', colors.ideal);
    
    % RHS: Actual spacing
    subplot(1, 2, 2);
    bar(1:K-1, spacing_error_percent, 'FaceColor', colors.actual, 'EdgeColor', 'none');
    hold on;
    yline(0, 'Color', colors.ideal, 'LineWidth', 2, 'LineStyle', '--', 'Label', 'Ideal (0%)');
    yline(mean(spacing_error_percent), 'Color', colors.accent2, 'LineWidth', 1.5, ...
          'Label', sprintf('Mean: %.2f%%', mean(spacing_error_percent)));
    hold off;
    xlabel('Antenna Pair Index', 'Color', colors.text);
    ylabel('Spacing Error (%)', 'Color', colors.text);
    title('ACTUAL: Hardware Impaired Array', 'Color', colors.actual, 'FontWeight', 'bold');
    ylim([-30, 30]);
    grid on;
    set(gca, 'XColor', colors.text, 'YColor', colors.text, 'GridColor', colors.grid);
    stats_str = sprintf('σ_λ = λ/30\nStd: %.2f%%\nMax: %.2f%%', ...
                        std(spacing_error_percent), max(abs(spacing_error_percent)));
    text(0.98, 0.95, stats_str, 'Units', 'normalized', 'HorizontalAlignment', 'right', ...
         'VerticalAlignment', 'top', 'FontSize', 9, ...
         'BackgroundColor', [1, 0.9, 0.9], 'EdgeColor', colors.actual);
    
    saveas(fig1, 'hardware_analysis/1_antenna_spacing_comparison.png');
    close(fig1);
    fprintf('  ✓ Saved: hardware_analysis/1_antenna_spacing_comparison.png\n');
    
    %======================================================================
    % PLOT 2: Array Geometry Comparison - Side by Side
    %======================================================================
    fig2 = figure('Name', 'Array Geometry Comparison', 'Position', [50, 50, 1200, 450], ...
                  'Color', 'white');
    set(gcf, 'InvertHardcopy', 'off');
    sgtitle('Array Geometry: Ideal vs Hardware Impaired', 'FontSize', 14, 'FontWeight', 'bold');
    
    ideal_norm = ideal_positions / lambda;
    impaired_norm = impaired_positions / lambda;
    
    % LHS: Ideal array
    subplot(1, 2, 1);
    plot(ideal_norm, zeros(K, 1), 'o', 'MarkerSize', 14, 'MarkerFaceColor', colors.ideal, ...
         'MarkerEdgeColor', 'black', 'LineWidth', 1.5);
    xlabel('Position (wavelengths)', 'Color', colors.text);
    ylabel('Array', 'Color', colors.text);
    title('IDEAL: Uniform Linear Array', 'Color', colors.ideal, 'FontWeight', 'bold');
    set(gca, 'YTick', 0, 'YTickLabel', {'Ideal'});
    ylim([-0.3, 0.3]);
    xlim([-0.5, max(ideal_norm)+0.5]);
    grid on;
    set(gca, 'XColor', colors.text, 'YColor', colors.text, 'GridColor', colors.grid);
    
    % RHS: Impaired array with deviation lines
    subplot(1, 2, 2);
    plot(ideal_norm, zeros(K, 1), 'o', 'MarkerSize', 12, 'MarkerFaceColor', colors.ideal, ...
         'MarkerEdgeColor', 'black', 'LineWidth', 1.5, 'DisplayName', 'Ideal');
    hold on;
    plot(impaired_norm, 0.15*ones(K, 1), 's', 'MarkerSize', 10, 'MarkerFaceColor', colors.actual, ...
         'MarkerEdgeColor', 'black', 'LineWidth', 1.5, 'DisplayName', 'Impaired');
    for k = 1:K
        plot([ideal_norm(k), impaired_norm(k)], [0, 0.15], ':', 'Color', colors.accent2, 'LineWidth', 1);
    end
    hold off;
    xlabel('Position (wavelengths)', 'Color', colors.text);
    ylabel('Array Type', 'Color', colors.text);
    title('ACTUAL: Impaired vs Ideal Overlay', 'Color', colors.actual, 'FontWeight', 'bold');
    legend('Ideal', 'Impaired', 'Location', 'southeast', 'Color', 'white');
    set(gca, 'YTick', [0, 0.15], 'YTickLabel', {'Ideal', 'Impaired'});
    ylim([-0.1, 0.25]);
    xlim([-0.5, max(impaired_norm)+0.5]);
    grid on;
    set(gca, 'XColor', colors.text, 'YColor', colors.text, 'GridColor', colors.grid);
    
    saveas(fig2, 'hardware_analysis/2_array_geometry_comparison.png');
    close(fig2);
    fprintf('  ✓ Saved: hardware_analysis/2_array_geometry_comparison.png\n');
    
    %======================================================================
    % PLOT 3: Beampattern Comparison - Side by Side
    %======================================================================
    fig3 = figure('Name', 'Beampattern Comparison', 'Position', [50, 50, 1200, 450], ...
                  'Color', 'white');
    set(gcf, 'InvertHardcopy', 'off');
    sgtitle('Beampattern: Ideal vs Hardware Impaired', 'FontSize', 14, 'FontWeight', 'bold');
    
    % Compute beampatterns
    theta_scan = linspace(-90, 90, 361);
    theta_steer = 0;
    
    beampattern_ideal = zeros(1, length(theta_scan));
    a_steer_ideal = steering_vector(deg2rad(theta_steer), K, d_nominal, lambda);
    for i = 1:length(theta_scan)
        a_scan = steering_vector(deg2rad(theta_scan(i)), K, d_nominal, lambda);
        beampattern_ideal(i) = abs(a_scan' * a_steer_ideal)^2;
    end
    
    beampattern_impaired = zeros(1, length(theta_scan));
    a_steer_impaired = steering_vector_impaired(deg2rad(theta_steer), K, d_spacings, lambda);
    for i = 1:length(theta_scan)
        a_scan = steering_vector_impaired(deg2rad(theta_scan(i)), K, d_spacings, lambda);
        beampattern_impaired(i) = abs(a_scan' * a_steer_impaired)^2;
    end
    
    beampattern_ideal_dB = 10*log10(beampattern_ideal / max(beampattern_ideal) + 1e-10);
    beampattern_impaired_dB = 10*log10(beampattern_impaired / max(beampattern_impaired) + 1e-10);
    
    % LHS: Ideal beampattern
    subplot(1, 2, 1);
    plot(theta_scan, beampattern_ideal_dB, 'Color', colors.ideal, 'LineWidth', 2);
    hold on;
    xregion([rad2deg(theta_min), rad2deg(theta_max)], 'FaceColor', colors.accent1, 'FaceAlpha', 0.2);
    xregion([rad2deg(vartheta_min), rad2deg(vartheta_max)], 'FaceColor', colors.accent2, 'FaceAlpha', 0.2);
    hold off;
    xlabel('Angle (degrees)', 'Color', colors.text);
    ylabel('Normalized Pattern (dB)', 'Color', colors.text);
    title('IDEAL: Perfect ULA Beampattern', 'Color', colors.ideal, 'FontWeight', 'bold');
    xlim([-90, 90]); ylim([-40, 5]);
    legend('Ideal', 'Radar Region', 'Comm Region', 'Location', 'southwest', 'Color', 'white');
    grid on;
    set(gca, 'XColor', colors.text, 'YColor', colors.text, 'GridColor', colors.grid);
    
    % RHS: Impaired beampattern
    subplot(1, 2, 2);
    plot(theta_scan, beampattern_impaired_dB, 'Color', colors.actual, 'LineWidth', 2);
    hold on;
    plot(theta_scan, beampattern_ideal_dB, '--', 'Color', colors.ideal, 'LineWidth', 1.5);
    xregion([rad2deg(theta_min), rad2deg(theta_max)], 'FaceColor', colors.accent1, 'FaceAlpha', 0.2);
    xregion([rad2deg(vartheta_min), rad2deg(vartheta_max)], 'FaceColor', colors.accent2, 'FaceAlpha', 0.2);
    hold off;
    xlabel('Angle (degrees)', 'Color', colors.text);
    ylabel('Normalized Pattern (dB)', 'Color', colors.text);
    title('ACTUAL: Impaired Beampattern (with Ideal overlay)', 'Color', colors.actual, 'FontWeight', 'bold');
    xlim([-90, 90]); ylim([-40, 5]);
    legend('Impaired', 'Ideal', 'Radar Region', 'Comm Region', 'Location', 'southwest', 'Color', 'white');
    grid on;
    set(gca, 'XColor', colors.text, 'YColor', colors.text, 'GridColor', colors.grid);
    
    saveas(fig3, 'hardware_analysis/3_beampattern_comparison.png');
    close(fig3);
    fprintf('  ✓ Saved: hardware_analysis/3_beampattern_comparison.png\n');
    
    %======================================================================
    % PLOT 4: Phase Error Analysis - Side by Side
    %======================================================================
    fig4 = figure('Name', 'Phase Error Analysis', 'Position', [50, 50, 1200, 450], ...
                  'Color', 'white');
    set(gcf, 'InvertHardcopy', 'off');
    sgtitle('Phase Error Analysis: Ideal vs Hardware Impaired', 'FontSize', 14, 'FontWeight', 'bold');
    
    test_angle = deg2rad(10);
    a_ideal = steering_vector(test_angle, K, d_nominal, lambda);
    a_impaired = steering_vector_impaired(test_angle, K, d_spacings, lambda);
    phase_ideal = rad2deg(angle(a_ideal));
    phase_impaired = rad2deg(angle(a_impaired));
    phase_error = wrapTo180(phase_impaired - phase_ideal);
    rms_error = sqrt(mean(phase_error.^2));
    
    % LHS: Ideal (zero error)
    subplot(1, 2, 1);
    bar(1:K, zeros(K, 1), 'FaceColor', colors.ideal, 'EdgeColor', 'none');
    hold on;
    yline(0, 'k--', 'LineWidth', 1.5);
    hold off;
    xlabel('Antenna Index', 'Color', colors.text);
    ylabel('Phase Error (degrees)', 'Color', colors.text);
    title(sprintf('IDEAL: Phase Error at θ = %.0f°', rad2deg(test_angle)), 'Color', colors.ideal, 'FontWeight', 'bold');
    ylim([-20, 20]);
    grid on;
    set(gca, 'XColor', colors.text, 'YColor', colors.text, 'GridColor', colors.grid);
    text(0.5, 0.9, 'RMS: 0.00°', 'Units', 'normalized', 'HorizontalAlignment', 'center', ...
         'FontSize', 10, 'FontWeight', 'bold', 'BackgroundColor', [0.9, 0.95, 0.9], 'EdgeColor', colors.ideal);
    
    % RHS: Actual phase error
    subplot(1, 2, 2);
    bar(1:K, phase_error, 'FaceColor', colors.accent2, 'EdgeColor', 'none');
    hold on;
    yline(0, 'k--', 'LineWidth', 1.5);
    hold off;
    xlabel('Antenna Index', 'Color', colors.text);
    ylabel('Phase Error (degrees)', 'Color', colors.text);
    title(sprintf('ACTUAL: Phase Error at θ = %.0f°', rad2deg(test_angle)), 'Color', colors.actual, 'FontWeight', 'bold');
    ylim([-20, 20]);
    grid on;
    set(gca, 'XColor', colors.text, 'YColor', colors.text, 'GridColor', colors.grid);
    text(0.98, 0.95, sprintf('RMS: %.2f°', rms_error), 'Units', 'normalized', ...
         'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
         'FontSize', 10, 'FontWeight', 'bold', 'BackgroundColor', [1, 0.9, 0.85], 'EdgeColor', colors.accent2);
    
    saveas(fig4, 'hardware_analysis/4_phase_error_comparison.png');
    close(fig4);
    fprintf('  ✓ Saved: hardware_analysis/4_phase_error_comparison.png\n');
    
    %======================================================================
    % PLOT 5: Beamforming Gain vs Omega_r
    %======================================================================
    fig5 = figure('Name', 'Beamforming Gain', 'Position', [50, 50, 800, 500], ...
                  'Color', 'white');
    set(gcf, 'InvertHardcopy', 'off');
    
    effective_snr_comm = zeros(length(omega_r_values), 1);
    effective_snr_radar = zeros(length(omega_r_values), 1);
    
    theta_c = (theta_min + theta_max) / 2;
    vartheta_c = (vartheta_min + vartheta_max) / 2;
    a_r = steering_vector_impaired(theta_c, K, d_spacings, lambda);
    a_c = steering_vector_impaired(vartheta_c, K, d_spacings, lambda);
    
    for i = 1:length(omega_r_values)
        omega_r = omega_r_values(i);
        v = sqrt(omega_r) * a_r + sqrt(1 - omega_r) * a_c;
        v = v / norm(v);
        gain_radar = abs(a_r' * v)^2;
        gain_comm = abs(a_c' * v)^2;
        effective_snr_radar(i) = 10*log10(K * gain_radar);
        effective_snr_comm(i) = 10*log10(gain_comm);
    end
    
    yyaxis left;
    plot(omega_r_values, effective_snr_comm, '-o', 'Color', colors.accent1, ...
         'LineWidth', 2, 'MarkerFaceColor', colors.accent1, 'MarkerSize', 8);
    ylabel('Comm Gain (dB)', 'Color', colors.accent1);
    set(gca, 'YColor', colors.accent1);
    
    yyaxis right;
    plot(omega_r_values, effective_snr_radar, '-s', 'Color', colors.accent2, ...
         'LineWidth', 2, 'MarkerFaceColor', colors.accent2, 'MarkerSize', 8);
    ylabel('Radar Gain (dB)', 'Color', colors.accent2);
    set(gca, 'YColor', colors.accent2);
    
    xlabel('\omega_r (Radar Allocation)', 'Color', colors.text);
    title('Effective Beamforming Gain vs \omega_r', 'Color', colors.text, 'FontWeight', 'bold', 'FontSize', 14);
    set(gca, 'XColor', colors.text, 'GridColor', colors.grid);
    grid on;
    legend('Comm Gain', 'Radar Gain', 'Location', 'east', 'Color', 'white');
    
    saveas(fig5, 'hardware_analysis/5_beamforming_gain.png');
    close(fig5);
    fprintf('  ✓ Saved: hardware_analysis/5_beamforming_gain.png\n');
    
    %======================================================================
    % PLOT 6: Hardware Impairment Summary Table (Fixed visibility)
    %======================================================================
    fig6 = figure('Name', 'Summary Table', 'Position', [50, 50, 600, 500], ...
                  'Color', 'white');
    set(gcf, 'InvertHardcopy', 'off');
    
    position_error_mm = (impaired_positions - ideal_positions') * 1000;
    max_pos_error = max(abs(position_error_mm));
    
    % Create table data
    param_data = {
        'Antenna Elements (K)', sprintf('%d', K);
        'Wavelength', sprintf('%.3f m', lambda);
        'Nominal Spacing', sprintf('λ/2 (%.4f m)', d_nominal);
        'Perturbation σ_λ', sprintf('λ/30 (%.5f m)', params.sigma_lambda);
        'Spacing Error Std', sprintf('%.3f%%', std(spacing_error_percent));
        'Max Spacing Error', sprintf('%.3f%%', max(abs(spacing_error_percent)));
        'Max Position Error', sprintf('%.3f mm', max_pos_error);
        'RMS Phase Error', sprintf('%.2f°', rms_error);
    };
    
    ax = gca;
    axis off;
    
    % Title
    text(0.5, 0.95, 'HARDWARE IMPAIRMENT SUMMARY', 'Units', 'normalized', ...
         'HorizontalAlignment', 'center', 'FontSize', 16, 'FontWeight', 'bold', 'Color', colors.accent1);
    
    % Create text-based table (compatible with saveas)
    y_start = 0.82;
    y_step = 0.08;
    
    % Draw header line
    text(0.5, y_start + 0.05, '─────────────────────────────────────────', ...
         'Units', 'normalized', 'HorizontalAlignment', 'center', 'FontSize', 10, ...
         'Color', colors.text, 'FontName', 'Consolas');
    
    % Draw table rows
    for i = 1:size(param_data, 1)
        y_pos = y_start - (i-1) * y_step;
        % Parameter name (left aligned)
        text(0.15, y_pos, param_data{i, 1}, 'Units', 'normalized', ...
             'HorizontalAlignment', 'left', 'FontSize', 11, 'Color', colors.text, ...
             'FontWeight', 'bold');
        % Value (right aligned)
        text(0.85, y_pos, param_data{i, 2}, 'Units', 'normalized', ...
             'HorizontalAlignment', 'right', 'FontSize', 11, 'Color', colors.accent1);
    end
    
    % Draw bottom line
    text(0.5, y_start - size(param_data, 1) * y_step, '─────────────────────────────────────────', ...
         'Units', 'normalized', 'HorizontalAlignment', 'center', 'FontSize', 10, ...
         'Color', colors.text, 'FontName', 'Consolas');
    
    saveas(fig6, 'hardware_analysis/6_summary_table.png');
    close(fig6);
    fprintf('  ✓ Saved: hardware_analysis/6_summary_table.png\n');
    
    fprintf('\n  ✓ All hardware analysis plots saved to hardware_analysis/\n');
end

